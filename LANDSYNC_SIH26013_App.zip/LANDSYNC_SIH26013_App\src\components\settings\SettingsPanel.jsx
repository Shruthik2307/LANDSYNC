import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { useFleet } from '../../context/FleetContext';
import { Settings, Shield, RefreshCw, Moon, Sun, Building, CheckCircle2 } from 'lucide-react';

export const SettingsPanel = () => {
  const { currentUser, company, theme, toggleTheme } = useAuth();
  const { resetToSeedData } = useFleet();

  const handleReset = () => {
    if (window.confirm('Are you sure you want to reset all data back to original seed data? All custom entries will be restored.')) {
      resetToSeedData();
      alert('System dataset restored successfully!');
    }
  };

  return (
    <div className="space-y-5 pb-20 max-w-3xl">
      <div>
        <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
          <Settings className="w-6 h-6 text-indigo-400" />
          <span>System Settings & RBAC Permissions Matrix</span>
        </h2>
        <p className="text-xs text-slate-400">
          Manage company profile, user permissions, theme preferences and demo data store.
        </p>
      </div>

      {/* Company Profile Card */}
      <div className="glass-card rounded-2xl p-5 border border-slate-700/60 space-y-3">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Building className="w-4 h-4 text-blue-400" />
          <span>Company Profile Information</span>
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <span className="text-slate-400 text-[10px]">Company Name</span>
            <div className="font-bold text-white">{company.name}</div>
          </div>
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <span className="text-slate-400 text-[10px]">Registration Number</span>
            <div className="font-bold text-white">{company.registrationNo}</div>
          </div>
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <span className="text-slate-400 text-[10px]">GSTIN Number</span>
            <div className="font-bold text-white">{company.gstin}</div>
          </div>
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <span className="text-slate-400 text-[10px]">Default Currency</span>
            <div className="font-bold text-emerald-400">₹ INR (Indian Rupee)</div>
          </div>
        </div>
      </div>

      {/* Role-Based Access Control Matrix */}
      <div className="glass-card rounded-2xl p-5 border border-slate-700/60 space-y-3">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Shield className="w-4 h-4 text-purple-400" />
          <span>Active Role Access Rights</span>
        </h3>
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 text-xs space-y-2">
          <div className="flex items-center justify-between font-bold text-white">
            <span>Your Current Active Role:</span>
            <span className="px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
              {currentUser.role}
            </span>
          </div>
          <div className="text-slate-400 text-[11px]">
            Use the top header role switcher dropdown at any time to test the app as Admin, Fleet Manager, or Driver.
          </div>
        </div>
      </div>

      {/* System Actions */}
      <div className="glass-card rounded-2xl p-5 border border-slate-700/60 space-y-4">
        <h3 className="text-sm font-bold text-white">Database & System Maintenance</h3>
        <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 text-xs">
          <div>
            <div className="font-bold text-white">Reset Demo Database</div>
            <div className="text-slate-400 text-[11px]">Restore initial 10 vehicles, 8 drivers & trips sample dataset</div>
          </div>
          <button
            onClick={handleReset}
            className="px-4 py-2 rounded-xl bg-rose-600/20 hover:bg-rose-600/40 text-rose-300 border border-rose-500/30 font-bold flex items-center gap-1.5 transition"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Reset Data</span>
          </button>
        </div>
      </div>
    </div>
  );
};
