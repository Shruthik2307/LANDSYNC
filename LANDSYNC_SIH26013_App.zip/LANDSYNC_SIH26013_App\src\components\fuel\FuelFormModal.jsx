import React, { useState } from 'react';
import { useFleet } from '../../context/FleetContext';
import { X, Fuel, Upload } from 'lucide-react';

export const FuelFormModal = ({ onClose, onSave }) => {
  const { vehicles, drivers } = useFleet();

  const [formData, setFormData] = useState({
    vehicleId: vehicles[0]?.id || '',
    driverId: drivers[0]?.id || '',
    date: new Date().toISOString().slice(0, 10),
    fuelType: 'Diesel',
    litres: 100,
    pricePerLitre: 92.5,
    totalCost: 9250,
    odometer: vehicles[0]?.currentOdometer || 60000,
    fuelStation: 'IndianOil Swagat Highway Hub',
    receiptPhoto: 'https://images.unsplash.com/photo-1527018601619-a508a2be00df?w=400&auto=format&fit=crop&q=80',
    notes: ''
  });

  const handleLitresOrPriceChange = (litres, price) => {
    setFormData((prev) => ({
      ...prev,
      litres,
      pricePerLitre: price,
      totalCost: Math.round(litres * price)
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.fuelStation || !formData.litres) {
      alert('Please fill in fuel station and litres filled.');
      return;
    }
    onSave(formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-3 sm:p-5">
      <div className="w-full max-w-lg glass-panel rounded-2xl border border-slate-700/80 p-5 shadow-2xl animate-fade-in max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between pb-4 border-b border-slate-700/60">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-amber-500/20 text-amber-400">
              <Fuel className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Log Fuel Fill Up</h2>
              <p className="text-xs text-slate-400">Record fuel station receipt & odometer</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto pt-4 space-y-3 text-xs pr-1">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Select Vehicle *</label>
              <select
                value={formData.vehicleId}
                onChange={(e) => {
                  const veh = vehicles.find((v) => v.id === e.target.value);
                  setFormData({
                    ...formData,
                    vehicleId: e.target.value,
                    odometer: veh?.currentOdometer || formData.odometer
                  });
                }}
                className="w-full glass-input rounded-xl px-3 py-2 bg-slate-900"
              >
                {vehicles.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.regNo} ({v.make})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Driver</label>
              <select
                value={formData.driverId}
                onChange={(e) => setFormData({ ...formData, driverId: e.target.value })}
                className="w-full glass-input rounded-xl px-3 py-2 bg-slate-900"
              >
                {drivers.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.fullName}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Fuel Station Name *</label>
              <input
                type="text"
                required
                placeholder="e.g. IndianOil / HPCL / BPCL Outlet"
                value={formData.fuelStation}
                onChange={(e) => setFormData({ ...formData, fuelStation: e.target.value })}
                className="w-full glass-input rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Transaction Date</label>
              <input
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="w-full glass-input rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Litres Filled *</label>
              <input
                type="number"
                required
                value={formData.litres}
                onChange={(e) => handleLitresOrPriceChange(Number(e.target.value), formData.pricePerLitre)}
                className="w-full glass-input rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Price Per Litre (₹)</label>
              <input
                type="number"
                step="0.01"
                value={formData.pricePerLitre}
                onChange={(e) => handleLitresOrPriceChange(formData.litres, Number(e.target.value))}
                className="w-full glass-input rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Calculated Total Cost (₹)</label>
              <input
                type="number"
                readOnly
                value={formData.totalCost}
                className="w-full glass-input rounded-xl px-3 py-2 text-amber-400 font-bold bg-slate-950"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Odometer Reading (KM)</label>
              <input
                type="number"
                value={formData.odometer}
                onChange={(e) => setFormData({ ...formData, odometer: Number(e.target.value) })}
                className="w-full glass-input rounded-xl px-3 py-2"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-700/60">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold shadow-lg shadow-amber-600/30"
            >
              Save Fuel Receipt
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
