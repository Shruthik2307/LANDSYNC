import React, { useState } from 'react';
import { useFleet } from '../../context/FleetContext';
import { getExpiryStatus, getDaysRemaining } from '../../utils/formatters';
import { FileText, Plus, Search, AlertTriangle, ShieldCheck, Download } from 'lucide-react';

export const DocumentsView = ({ onOpenAddDocument }) => {
  const { documents, vehicles, drivers } = useFleet();
  const [searchQuery, setSearchQuery] = useState('');

  const filtered = documents.filter((d) => {
    return (
      d.docType.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.docNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.entityId.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  return (
    <div className="space-y-5 pb-20">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
            <FileText className="w-6 h-6 text-emerald-400" />
            <span>Document Vault & Compliance ({documents.length})</span>
          </h2>
          <p className="text-xs text-slate-400">
            RC smartcards, Insurance policies, PUC certificates & Driver license expiration system.
          </p>
        </div>

        <button
          onClick={onOpenAddDocument}
          className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/30 transition"
        >
          <Plus className="w-4 h-4" />
          <span>Upload Document</span>
        </button>
      </div>

      <div className="glass-card rounded-2xl p-4 border border-slate-700/60">
        <input
          type="text"
          placeholder="Search document type, number or vehicle ID..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full glass-input rounded-xl px-3 py-2 text-xs"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((doc) => {
          const statusInfo = getExpiryStatus(doc.expiryDate);
          const days = getDaysRemaining(doc.expiryDate);

          return (
            <div key={doc.id} className="glass-card rounded-2xl p-4 border border-slate-700/60 flex flex-col justify-between space-y-3">
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
                      {doc.docType}
                    </span>
                    <h3 className="text-sm font-extrabold text-white mt-1">{doc.docNumber}</h3>
                    <div className="text-xs text-slate-400">Entity: {doc.entityId}</div>
                  </div>
                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${statusInfo.color}`}>
                    {statusInfo.label}
                  </span>
                </div>

                <div className="mt-3 p-2.5 rounded-xl bg-slate-900/60 border border-slate-800 text-xs space-y-1">
                  <div className="flex justify-between text-slate-400">
                    <span>Issued: {doc.issueDate}</span>
                    <span>Expires: {doc.expiryDate}</span>
                  </div>
                  {doc.notes && <div className="text-[11px] text-slate-300 italic pt-1">{doc.notes}</div>}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
                <span className="text-[10px] text-slate-400">
                  {days < 0 ? 'Expired' : `${days} days remaining`}
                </span>
                {doc.fileUrl && (
                  <a
                    href={doc.fileUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 rounded-lg bg-blue-600/20 hover:bg-blue-600/40 text-blue-300 text-xs font-bold border border-blue-500/30 flex items-center gap-1 transition"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>View File</span>
                  </a>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
