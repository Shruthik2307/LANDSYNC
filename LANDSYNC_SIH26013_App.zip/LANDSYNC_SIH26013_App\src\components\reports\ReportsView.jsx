import React, { useState } from 'react';
import { useFleet } from '../../context/FleetContext';
import { formatCurrency, formatNumber, exportToCSV } from '../../utils/formatters';
import { BarChart3, Download, Printer, FileSpreadsheet, Calendar, Filter } from 'lucide-react';

export const ReportsView = () => {
  const { vehicles, drivers, trips, fuel, maintenance, expenses } = useFleet();
  const [reportType, setReportType] = useState('Fleet Summary');
  const [showPrintModal, setShowPrintModal] = useState(false);

  const handleExportCSV = () => {
    let filename = `FleetPulse_${reportType.replace(/\s+/g, '_')}`;
    let data = [];

    if (reportType === 'Fleet Summary') {
      data = vehicles.map((v) => ({
        RegNo: v.regNo,
        Make: v.make,
        Model: v.model,
        Type: v.type,
        FuelType: v.fuelType,
        Status: v.status,
        Odometer: v.currentOdometer,
        Driver: drivers.find((d) => d.id === v.assignedDriverId)?.fullName || 'Unassigned'
      }));
    } else if (reportType === 'Fuel Report') {
      data = fuel.map((f) => ({
        Vehicle: f.vehicleId,
        Date: f.date,
        FuelStation: f.fuelStation,
        Litres: f.litres,
        PricePerLitre: f.pricePerLitre,
        TotalCost: f.totalCost,
        Odometer: f.odometer
      }));
    } else if (reportType === 'Trip Report') {
      data = trips.map((t) => ({
        TripID: t.id,
        Customer: t.customerName,
        From: t.startLocation,
        To: t.destination,
        DistanceKM: t.distanceKm,
        Status: t.status,
        Revenue: t.revenue,
        Expenses: t.expenses,
        NetProfit: (t.revenue || 0) - (t.expenses || 0)
      }));
    } else {
      data = expenses.map((e) => ({
        ExpenseID: e.id,
        Category: e.category,
        Amount: e.amount,
        Vehicle: e.vehicleId,
        Vendor: e.vendor,
        Date: e.date
      }));
    }

    exportToCSV(filename, data);
  };

  return (
    <div className="space-y-5 pb-20">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-blue-400" />
            <span>Reports & Executive Data Export</span>
          </h2>
          <p className="text-xs text-slate-400">
            Generate fleet profitability, fuel mileage, servicing spend & CSV export.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-emerald-600/30 transition"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => window.print()}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs flex items-center gap-2 transition"
          >
            <Printer className="w-4 h-4" />
            <span>Print Report</span>
          </button>
        </div>
      </div>

      {/* Report Selector Pills */}
      <div className="glass-card rounded-2xl p-4 border border-slate-700/60 flex items-center gap-2 overflow-x-auto no-scrollbar">
        {['Fleet Summary', 'Fuel Report', 'Trip Report', 'Expense Report'].map((rep) => (
          <button
            key={rep}
            onClick={() => setReportType(rep)}
            className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition ${
              reportType === rep
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                : 'bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700/60'
            }`}
          >
            {rep}
          </button>
        ))}
      </div>

      {/* Report Preview Surface */}
      <div className="glass-card rounded-2xl p-5 border border-slate-700/60 space-y-4 print:bg-white print:text-black">
        <div className="flex items-center justify-between border-b border-slate-700/60 pb-3">
          <div>
            <h3 className="text-base font-extrabold text-white">{reportType}</h3>
            <p className="text-xs text-slate-400">Generated on {new Date().toLocaleDateString()}</p>
          </div>
          <span className="text-xs font-bold px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30">
            Official Audit Record
          </span>
        </div>

        {reportType === 'Fleet Summary' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-900/80 text-slate-400 uppercase font-semibold border-b border-slate-800">
                <tr>
                  <th className="p-2.5">Reg No</th>
                  <th className="p-2.5">Make & Model</th>
                  <th className="p-2.5">Type</th>
                  <th className="p-2.5">Fuel</th>
                  <th className="p-2.5">Odometer</th>
                  <th className="p-2.5">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {vehicles.map((v) => (
                  <tr key={v.id}>
                    <td className="p-2.5 font-bold text-white">{v.regNo}</td>
                    <td className="p-2.5">{v.make} {v.model}</td>
                    <td className="p-2.5">{v.type}</td>
                    <td className="p-2.5">{v.fuelType}</td>
                    <td className="p-2.5">{formatNumber(v.currentOdometer)} KM</td>
                    <td className="p-2.5 font-bold text-blue-400">{v.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {reportType === 'Trip Report' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-900/80 text-slate-400 uppercase font-semibold border-b border-slate-800">
                <tr>
                  <th className="p-2.5">Trip ID</th>
                  <th className="p-2.5">Customer</th>
                  <th className="p-2.5">Route</th>
                  <th className="p-2.5">Distance</th>
                  <th className="p-2.5">Revenue</th>
                  <th className="p-2.5">Profit</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {trips.map((t) => (
                  <tr key={t.id}>
                    <td className="p-2.5 font-bold text-purple-400">{t.id}</td>
                    <td className="p-2.5 text-white font-semibold">{t.customerName}</td>
                    <td className="p-2.5">{t.startLocation} ➔ {t.destination}</td>
                    <td className="p-2.5">{t.distanceKm} KM</td>
                    <td className="p-2.5 font-bold text-emerald-400">{formatCurrency(t.revenue)}</td>
                    <td className="p-2.5 font-bold text-emerald-400">{formatCurrency((t.revenue || 0) - (t.expenses || 0))}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
