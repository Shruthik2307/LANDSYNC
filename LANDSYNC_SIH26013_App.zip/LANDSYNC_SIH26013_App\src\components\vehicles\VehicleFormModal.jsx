import React, { useState } from 'react';
import { useFleet } from '../../context/FleetContext';
import { X, Truck, Upload } from 'lucide-react';

export const VehicleFormModal = ({ vehicle, onClose, onSave }) => {
  const { drivers } = useFleet();

  const [formData, setFormData] = useState({
    regNo: vehicle?.regNo || '',
    type: vehicle?.type || 'Heavy Truck',
    make: vehicle?.make || 'Tata Motors',
    model: vehicle?.model || '',
    year: vehicle?.year || new Date().getFullYear(),
    color: vehicle?.color || 'Pure White',
    fuelType: vehicle?.fuelType || 'Diesel',
    tankCapacity: vehicle?.tankCapacity || 300,
    currentOdometer: vehicle?.currentOdometer || 0,
    status: vehicle?.status || 'Available',
    assignedDriverId: vehicle?.assignedDriverId || '',
    purchaseDate: vehicle?.purchaseDate || new Date().toISOString().slice(0, 10),
    purchasePrice: vehicle?.purchasePrice || 3500000,
    insuranceExpiry: vehicle?.insuranceExpiry || '2027-08-30',
    registrationExpiry: vehicle?.registrationExpiry || '2038-08-30',
    permitExpiry: vehicle?.permitExpiry || '2027-08-30',
    pollutionExpiry: vehicle?.pollutionExpiry || '2027-02-28',
    photo: vehicle?.photo || 'https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?w=600&auto=format&fit=crop&q=80',
    notes: vehicle?.notes || ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.regNo || !formData.make || !formData.model) {
      alert('Please fill in required fields: Registration No, Make, and Model.');
      return;
    }
    onSave(formData);
    onClose();
  };

  const handlePhotoUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData((prev) => ({ ...prev, photo: reader.result }));
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-3 sm:p-5">
      <div className="w-full max-w-2xl glass-panel rounded-2xl border border-slate-700/80 p-5 shadow-2xl animate-fade-in max-h-[90vh] flex flex-col">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-700/60">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-blue-500/20 text-blue-400">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                {vehicle ? 'Edit Vehicle Specifications' : 'Register New Fleet Vehicle'}
              </h2>
              <p className="text-xs text-slate-400">Input vehicle registration & technical parameters</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto pt-4 space-y-4 pr-1 text-xs">
          {/* Photo Preview & Uploader */}
          <div className="flex items-center gap-4 p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <div className="w-20 h-16 rounded-lg overflow-hidden bg-slate-800 border border-slate-700">
              <img src={formData.photo} alt="Preview" className="w-full h-full object-cover" />
            </div>
            <div>
              <label className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer transition">
                <Upload className="w-3.5 h-3.5" />
                <span>Upload Photo</span>
                <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
              </label>
              <p className="text-[10px] text-slate-400 mt-1">PNG, JPG or WebP (max 5MB)</p>
            </div>
          </div>

          {/* Registration & Basic Spec */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Registration Number *</label>
              <input
                type="text"
                required
                placeholder="e.g. MH 12 AB 1234"
                value={formData.regNo}
                onChange={(e) => setFormData({ ...formData, regNo: e.target.value.toUpperCase() })}
                className="w-full glass-input rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Vehicle Type</label>
              <select
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                className="w-full glass-input rounded-xl px-3 py-2 bg-slate-900"
              >
                <option value="Heavy Truck">Heavy Truck</option>
                <option value="Medium Truck">Medium Truck</option>
                <option value="Mini Pickup">Mini Pickup</option>
                <option value="Light Utility Pickup">Light Utility Pickup</option>
                <option value="Electric Cargo Van">Electric Cargo Van</option>
                <option value="Passenger Van">Passenger Van</option>
                <option value="Sedan Fleet">Sedan Fleet</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Make / Manufacturer *</label>
              <input
                type="text"
                required
                placeholder="e.g. Tata Motors, Eicher, Ashok Leyland"
                value={formData.make}
                onChange={(e) => setFormData({ ...formData, make: e.target.value })}
                className="w-full glass-input rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Model Name *</label>
              <input
                type="text"
                required
                placeholder="e.g. Prima 5530.S"
                value={formData.model}
                onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                className="w-full glass-input rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Manufacturing Year</label>
              <input
                type="number"
                value={formData.year}
                onChange={(e) => setFormData({ ...formData, year: Number(e.target.value) })}
                className="w-full glass-input rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Fuel Type</label>
              <select
                value={formData.fuelType}
                onChange={(e) => setFormData({ ...formData, fuelType: e.target.value })}
                className="w-full glass-input rounded-xl px-3 py-2 bg-slate-900"
              >
                <option value="Diesel">Diesel</option>
                <option value="Petrol">Petrol</option>
                <option value="CNG">CNG</option>
                <option value="EV">EV (Electric)</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Tank Capacity (L / kWh)</label>
              <input
                type="number"
                value={formData.tankCapacity}
                onChange={(e) => setFormData({ ...formData, tankCapacity: Number(e.target.value) })}
                className="w-full glass-input rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Current Odometer Reading (KM)</label>
              <input
                type="number"
                value={formData.currentOdometer}
                onChange={(e) => setFormData({ ...formData, currentOdometer: Number(e.target.value) })}
                className="w-full glass-input rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Assigned Driver</label>
              <select
                value={formData.assignedDriverId || ''}
                onChange={(e) => setFormData({ ...formData, assignedDriverId: e.target.value })}
                className="w-full glass-input rounded-xl px-3 py-2 bg-slate-900"
              >
                <option value="">Unassigned</option>
                {drivers.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.fullName} ({d.phone})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Insurance Expiry Date</label>
              <input
                type="date"
                value={formData.insuranceExpiry}
                onChange={(e) => setFormData({ ...formData, insuranceExpiry: e.target.value })}
                className="w-full glass-input rounded-xl px-3 py-2"
              />
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-700/60">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold shadow-lg shadow-blue-600/30"
            >
              {vehicle ? 'Save Changes' : 'Register Vehicle'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
