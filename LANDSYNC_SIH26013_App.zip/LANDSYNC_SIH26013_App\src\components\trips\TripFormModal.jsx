import React, { useState } from 'react';
import { useFleet } from '../../context/FleetContext';
import { X, MapPin } from 'lucide-react';

export const TripFormModal = ({ onClose, onSave }) => {
  const { vehicles, drivers } = useFleet();

  const [formData, setFormData] = useState({
    vehicleId: vehicles[0]?.id || '',
    driverId: drivers[0]?.id || '',
    customerName: '',
    startLocation: '',
    destination: '',
    startDate: new Date().toISOString().replace('T', ' ').slice(0, 16),
    expectedArrival: new Date(Date.now() + 86400000).toISOString().replace('T', ' ').slice(0, 16),
    startOdometer: vehicles[0]?.currentOdometer || 50000,
    distanceKm: 250,
    revenue: 25000,
    expenses: 4500,
    notes: ''
  });

  const handleVehicleChange = (vehId) => {
    const veh = vehicles.find((v) => v.id === vehId);
    setFormData((prev) => ({
      ...prev,
      vehicleId: vehId,
      driverId: veh?.assignedDriverId || prev.driverId,
      startOdometer: veh?.currentOdometer || prev.startOdometer
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.customerName || !formData.startLocation || !formData.destination) {
      alert('Please fill in Customer, Starting Location, and Destination.');
      return;
    }
    onSave(formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-3 sm:p-5">
      <div className="w-full max-w-xl glass-panel rounded-2xl border border-slate-700/80 p-5 shadow-2xl animate-fade-in max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between pb-4 border-b border-slate-700/60">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-purple-500/20 text-purple-400">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Dispatch New Commercial Trip</h2>
              <p className="text-xs text-slate-400">Set route, customer billing, and assign fleet unit</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto pt-4 space-y-3 text-xs pr-1">
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Customer / Client Name *</label>
            <input
              type="text"
              required
              placeholder="e.g. Reliance Industries / Amazon FC"
              value={formData.customerName}
              onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
              className="w-full glass-input rounded-xl px-3 py-2"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Select Vehicle *</label>
              <select
                value={formData.vehicleId}
                onChange={(e) => handleVehicleChange(e.target.value)}
                className="w-full glass-input rounded-xl px-3 py-2 bg-slate-900"
              >
                {vehicles.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.regNo} ({v.make} - {v.status})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Assigned Driver *</label>
              <select
                value={formData.driverId}
                onChange={(e) => setFormData({ ...formData, driverId: e.target.value })}
                className="w-full glass-input rounded-xl px-3 py-2 bg-slate-900"
              >
                {drivers.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.fullName} ({d.phone})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Starting Location *</label>
              <input
                type="text"
                required
                placeholder="e.g. Bhiwandi Logistics Hub, Mumbai"
                value={formData.startLocation}
                onChange={(e) => setFormData({ ...formData, startLocation: e.target.value })}
                className="w-full glass-input rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Destination *</label>
              <input
                type="text"
                required
                placeholder="e.g. Peenya MIDC, Bengaluru"
                value={formData.destination}
                onChange={(e) => setFormData({ ...formData, destination: e.target.value })}
                className="w-full glass-input rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Starting Odometer (KM)</label>
              <input
                type="number"
                value={formData.startOdometer}
                onChange={(e) => setFormData({ ...formData, startOdometer: Number(e.target.value) })}
                className="w-full glass-input rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Estimated Distance (KM)</label>
              <input
                type="number"
                value={formData.distanceKm}
                onChange={(e) => setFormData({ ...formData, distanceKm: Number(e.target.value) })}
                className="w-full glass-input rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Trip Revenue (₹ INR)</label>
              <input
                type="number"
                value={formData.revenue}
                onChange={(e) => setFormData({ ...formData, revenue: Number(e.target.value) })}
                className="w-full glass-input rounded-xl px-3 py-2 text-emerald-400 font-bold"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Estimated Expenses (₹ INR)</label>
              <input
                type="number"
                value={formData.expenses}
                onChange={(e) => setFormData({ ...formData, expenses: Number(e.target.value) })}
                className="w-full glass-input rounded-xl px-3 py-2 text-rose-400 font-bold"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-700/60">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold shadow-lg shadow-purple-600/30"
            >
              Dispatch Trip
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
