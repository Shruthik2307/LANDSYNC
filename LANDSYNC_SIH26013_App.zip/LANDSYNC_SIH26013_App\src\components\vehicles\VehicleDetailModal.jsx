import React, { useState } from 'react';
import { useFleet } from '../../context/FleetContext';
import { formatCurrency, formatDate, formatNumber, getVehicleStatusColor } from '../../utils/formatters';
import {
  X,
  Truck,
  MapPin,
  Fuel,
  Wrench,
  DollarSign,
  FileText,
  BarChart3,
  UserCheck,
  Calendar,
  Gauge,
  Info,
  Edit,
  Trash2
} from 'lucide-react';

export const VehicleDetailModal = ({ vehicle, onClose, onEdit, onDelete }) => {
  const { drivers, trips, fuel, maintenance, expenses, documents } = useFleet();
  const [activeTab, setActiveTab] = useState('Overview');

  if (!vehicle) return null;

  const driver = drivers.find((d) => d.id === vehicle.assignedDriverId);
  const vehicleTrips = trips.filter((t) => t.vehicleId === vehicle.id);
  const vehicleFuel = fuel.filter((f) => f.vehicleId === vehicle.id);
  const vehicleMaintenance = maintenance.filter((m) => m.vehicleId === vehicle.id);
  const vehicleExpenses = expenses.filter((e) => e.vehicleId === vehicle.id);
  const vehicleDocs = documents.filter((d) => d.entityId === vehicle.id);

  // Analytics calculations
  const totalKm = vehicleTrips.reduce((acc, t) => acc + (t.distanceKm || 0), 0);
  const totalFuelSpend = vehicleFuel.reduce((acc, f) => acc + (f.totalCost || 0), 0);
  const totalMntSpend = vehicleMaintenance.reduce((acc, m) => acc + (m.totalCost || 0), 0);
  const totalExpSpend = vehicleExpenses.reduce((acc, e) => acc + (e.amount || 0), 0);
  const totalOperatingCost = totalExpSpend;
  const costPerKm = totalKm > 0 ? (totalOperatingCost / totalKm).toFixed(2) : '0.00';
  const totalFuelLitres = vehicleFuel.reduce((acc, f) => acc + (f.litres || 0), 0);
  const fuelEfficiency = totalFuelLitres > 0 && totalKm > 0 ? (totalKm / totalFuelLitres).toFixed(1) : 'N/A';

  const tabs = ['Overview', 'Trips', 'Fuel', 'Maintenance', 'Expenses', 'Documents', 'Analytics'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-3 sm:p-5">
      <div className="w-full max-w-4xl glass-panel rounded-2xl border border-slate-700/80 p-5 shadow-2xl animate-fade-in max-h-[90vh] flex flex-col">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-700/60">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-slate-900 overflow-hidden border border-slate-700">
              <img src={vehicle.photo} alt={vehicle.regNo} className="w-full h-full object-cover" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-white">{vehicle.regNo}</h2>
                <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${getVehicleStatusColor(vehicle.status)}`}>
                  {vehicle.status}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {vehicle.make} {vehicle.model} ({vehicle.type}) — {vehicle.fuelType}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onEdit(vehicle)}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-blue-400 transition"
              title="Edit Vehicle"
            >
              <Edit className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Strip */}
        <div className="flex items-center gap-1 overflow-x-auto py-3 border-b border-slate-700/60 no-scrollbar">
          {tabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                activeTab === tab
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Tab Body Content */}
        <div className="flex-1 overflow-y-auto pt-4 space-y-4 pr-1">
          {/* OVERVIEW TAB */}
          {activeTab === 'Overview' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/50">
                  <div className="text-[11px] text-slate-400 flex items-center gap-1">
                    <UserCheck className="w-3.5 h-3.5 text-blue-400" />
                    Assigned Driver
                  </div>
                  <div className="text-sm font-bold text-white mt-1">
                    {driver ? driver.fullName : 'Unassigned'}
                  </div>
                  <div className="text-[10px] text-slate-400">{driver ? driver.phone : 'N/A'}</div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/50">
                  <div className="text-[11px] text-slate-400 flex items-center gap-1">
                    <Gauge className="w-3.5 h-3.5 text-emerald-400" />
                    Current Odometer
                  </div>
                  <div className="text-sm font-bold text-emerald-400 mt-1">
                    {formatNumber(vehicle.currentOdometer)} KM
                  </div>
                  <div className="text-[10px] text-slate-400">Total logged reading</div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/50">
                  <div className="text-[11px] text-slate-400 flex items-center gap-1">
                    <Fuel className="w-3.5 h-3.5 text-amber-400" />
                    Fuel Tank Capacity
                  </div>
                  <div className="text-sm font-bold text-white mt-1">
                    {vehicle.tankCapacity} Litres ({vehicle.fuelType})
                  </div>
                  <div className="text-[10px] text-slate-400">Full tank size</div>
                </div>
              </div>

              {/* Vehicle Spec Grid */}
              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 space-y-3">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  Registration & Compliance Dates
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div>
                    <span className="text-slate-400 text-[10px]">Purchase Date</span>
                    <div className="font-semibold text-white">{formatDate(vehicle.purchaseDate)}</div>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px]">Insurance Expiry</span>
                    <div className="font-semibold text-amber-400">{formatDate(vehicle.insuranceExpiry)}</div>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px]">National Permit Expiry</span>
                    <div className="font-semibold text-rose-400">{formatDate(vehicle.permitExpiry)}</div>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px]">PUC Certificate Expiry</span>
                    <div className="font-semibold text-emerald-400">{formatDate(vehicle.pollutionExpiry)}</div>
                  </div>
                </div>
              </div>

              {/* Notes */}
              {vehicle.notes && (
                <div className="p-3.5 rounded-xl bg-blue-500/10 border border-blue-500/20 text-xs text-slate-300">
                  <span className="font-bold text-blue-400">Vehicle Notes:</span> {vehicle.notes}
                </div>
              )}
            </div>
          )}

          {/* TRIPS TAB */}
          {activeTab === 'Trips' && (
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-400 uppercase">Trip History ({vehicleTrips.length})</h4>
              {vehicleTrips.map((t) => (
                <div key={t.id} className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/50 flex items-center justify-between text-xs">
                  <div>
                    <div className="font-bold text-white">{t.startLocation} ➔ {t.destination}</div>
                    <div className="text-slate-400 text-[11px]">Customer: {t.customerName} | Date: {t.startDate}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-blue-400">{t.distanceKm} KM</div>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-blue-500/20 text-blue-300">{t.status}</span>
                  </div>
                </div>
              ))}
              {vehicleTrips.length === 0 && <div className="text-center text-slate-400 text-xs py-4">No trips logged yet.</div>}
            </div>
          )}

          {/* FUEL TAB */}
          {activeTab === 'Fuel' && (
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-400 uppercase">Fuel Transactions ({vehicleFuel.length})</h4>
              {vehicleFuel.map((f) => (
                <div key={f.id} className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/50 flex items-center justify-between text-xs">
                  <div>
                    <div className="font-bold text-white">{f.fuelStation}</div>
                    <div className="text-slate-400 text-[11px]">{f.date} | {f.litres}L @ ₹{f.pricePerLitre}/L</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-amber-400">{formatCurrency(f.totalCost)}</div>
                    <div className="text-[10px] text-slate-400">Odo: {f.odometer} KM</div>
                  </div>
                </div>
              ))}
              {vehicleFuel.length === 0 && <div className="text-center text-slate-400 text-xs py-4">No fuel entries logged yet.</div>}
            </div>
          )}

          {/* MAINTENANCE TAB */}
          {activeTab === 'Maintenance' && (
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-400 uppercase">Service History ({vehicleMaintenance.length})</h4>
              {vehicleMaintenance.map((m) => (
                <div key={m.id} className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/50 space-y-1 text-xs">
                  <div className="flex items-center justify-between font-bold text-white">
                    <span>{m.serviceType}</span>
                    <span className="text-blue-400">{formatCurrency(m.totalCost)}</span>
                  </div>
                  <div className="text-slate-400 text-[11px]">Provider: {m.serviceProvider} | Date: {m.date}</div>
                  <div className="text-slate-300 text-[11px]">Parts: {m.partsReplaced}</div>
                </div>
              ))}
              {vehicleMaintenance.length === 0 && <div className="text-center text-slate-400 text-xs py-4">No maintenance history.</div>}
            </div>
          )}

          {/* EXPENSES TAB */}
          {activeTab === 'Expenses' && (
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-400 uppercase">Vehicle Expense History ({vehicleExpenses.length})</h4>
              {vehicleExpenses.map((e) => (
                <div key={e.id} className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/50 flex items-center justify-between text-xs">
                  <div>
                    <div className="font-bold text-white">{e.category} - {e.description}</div>
                    <div className="text-slate-400 text-[11px]">{e.date} | Vendor: {e.vendor}</div>
                  </div>
                  <div className="font-bold text-rose-400">{formatCurrency(e.amount)}</div>
                </div>
              ))}
              {vehicleExpenses.length === 0 && <div className="text-center text-slate-400 text-xs py-4">No expenses recorded.</div>}
            </div>
          )}

          {/* DOCUMENTS TAB */}
          {activeTab === 'Documents' && (
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-400 uppercase">Stored Vehicle Documents ({vehicleDocs.length})</h4>
              {vehicleDocs.map((d) => (
                <div key={d.id} className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/50 flex items-center justify-between text-xs">
                  <div>
                    <div className="font-bold text-white">{d.docType} ({d.docNumber})</div>
                    <div className="text-slate-400 text-[11px]">Expires: {d.expiryDate}</div>
                  </div>
                  <a href={d.fileUrl} target="_blank" rel="noreferrer" className="px-2.5 py-1 rounded bg-blue-600/30 text-blue-300 text-[11px] font-bold">
                    View
                  </a>
                </div>
              ))}
            </div>
          )}

          {/* ANALYTICS TAB */}
          {activeTab === 'Analytics' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/50">
                  <div className="text-[10px] text-slate-400">Total Operating Spend</div>
                  <div className="text-base font-bold text-rose-400 mt-1">{formatCurrency(totalOperatingCost)}</div>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/50">
                  <div className="text-[10px] text-slate-400">Total Distance Logged</div>
                  <div className="text-base font-bold text-white mt-1">{formatNumber(totalKm)} KM</div>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/50">
                  <div className="text-[10px] text-slate-400">Cost Per Kilometer</div>
                  <div className="text-base font-bold text-blue-400 mt-1">₹{costPerKm} / KM</div>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/50">
                  <div className="text-[10px] text-slate-400">Fuel Efficiency</div>
                  <div className="text-base font-bold text-emerald-400 mt-1">{fuelEfficiency} km/L</div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
