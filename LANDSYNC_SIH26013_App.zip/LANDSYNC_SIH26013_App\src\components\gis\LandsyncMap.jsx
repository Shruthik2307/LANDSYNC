import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Polygon, CircleMarker, Popup, Tooltip, LayersControl, LayerGroup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Layers, Eye, EyeOff, AlertTriangle, CheckCircle, Sliders, MapPin, Sparkles } from 'lucide-react';

// Fix Leaflet default icon paths in React build
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

// Component to dynamically re-center map when selected parcel changes
function MapRecenter({ center }) {
  const map = useMap();
  useEffect(() => {
    if (center) {
      map.flyTo(center, 17, { duration: 1.2 });
    }
  }, [center, map]);
  return null;
}

export default function LandsyncMap({ parcels, selectedParcelId, onSelectParcel, activeLayers, onToggleLayer }) {
  const [mapTile, setMapTile] = useState('satellite');
  const [droneOpacity, setDroneOpacity] = useState(0.65);
  const [showDifferenceOverlay, setShowDifferenceOverlay] = useState(true);

  // Center coordinate around Kondapur / Gachibowli demo area
  const defaultCenter = [17.4468, 78.3765];

  const selectedParcel = parcels.find(p => p.parcel_id === selectedParcelId);
  const mapCenter = selectedParcel
    ? selectedParcel.coordinates[0]
    : defaultCenter;

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'HIGH': return '#ef4444'; // Red
      case 'MEDIUM': return '#f59e0b'; // Amber
      case 'LOW': return '#10b981'; // Emerald
      default: return '#3b82f6';
    }
  };

  return (
    <div className="relative w-full h-[620px] rounded-2xl overflow-hidden border border-slate-700/60 shadow-2xl bg-slate-900">
      
      {/* Web-GIS Map Control Toolbar */}
      <div className="absolute top-4 left-4 z-[1000] flex flex-wrap items-center gap-2 bg-slate-900/90 backdrop-blur-md px-4 py-2.5 rounded-xl border border-slate-700/80 shadow-lg">
        <div className="flex items-center gap-2 pr-3 border-r border-slate-700">
          <Layers className="w-4 h-4 text-emerald-400" />
          <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider">Web-GIS Layers</span>
        </div>

        {/* Layer Toggles */}
        <button
          onClick={() => onToggleLayer('cadastral')}
          className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 ${
            activeLayers.cadastral
              ? 'bg-blue-600/30 text-blue-300 border border-blue-500/50'
              : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
          }`}
        >
          <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
          Cadastral Boundary
        </button>

        <button
          onClick={() => onToggleLayer('drone_ori')}
          className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 ${
            activeLayers.drone_ori
              ? 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/50'
              : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
          }`}
        >
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
          Drone ORI Layer
        </button>

        <button
          onClick={() => onToggleLayer('ground_truthing')}
          className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 ${
            activeLayers.ground_truthing
              ? 'bg-cyan-600/30 text-cyan-300 border border-cyan-500/50'
              : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
          }`}
        >
          <span className="w-2.5 h-2.5 rounded-full bg-cyan-400"></span>
          GNSS GT Points
        </button>

        <button
          onClick={() => onToggleLayer('conflicts')}
          className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 ${
            activeLayers.conflicts
              ? 'bg-rose-600/30 text-rose-300 border border-rose-500/50'
              : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
          }`}
        >
          <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
          Conflict Heatmap
        </button>

        {/* Basemap Tile Switcher */}
        <div className="ml-auto flex items-center gap-1 bg-slate-800 p-0.5 rounded-lg border border-slate-700">
          <button
            onClick={() => setMapTile('satellite')}
            className={`px-2 py-0.5 text-[11px] rounded font-medium ${mapTile === 'satellite' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400'}`}
          >
            Satellite
          </button>
          <button
            onClick={() => setMapTile('dark')}
            className={`px-2 py-0.5 text-[11px] rounded font-medium ${mapTile === 'dark' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400'}`}
          >
            Dark Vector
          </button>
        </div>
      </div>

      {/* Drone Layer Opacity Slider & Side-by-Side Toggle Bar */}
      {activeLayers.drone_ori && (
        <div className="absolute bottom-4 left-4 z-[1000] flex items-center gap-3 bg-slate-900/90 backdrop-blur-md px-3.5 py-2 rounded-xl border border-slate-700 shadow-lg">
          <Sliders className="w-4 h-4 text-emerald-400" />
          <span className="text-xs text-slate-300 font-medium">Drone Layer Opacity:</span>
          <input
            type="range"
            min="0.1"
            max="1.0"
            step="0.05"
            value={droneOpacity}
            onChange={(e) => setDroneOpacity(parseFloat(e.target.value))}
            className="w-24 accent-emerald-500 cursor-pointer"
          />
          <span className="text-xs font-bold text-emerald-400 w-8">{Math.round(droneOpacity * 100)}%</span>
        </div>
      )}

      {/* Main Map Container */}
      <MapContainer
        center={defaultCenter}
        zoom={16}
        scrollWheelZoom={true}
        className="w-full h-full"
      >
        <MapRecenter center={mapCenter} />

        {/* Tile Layers */}
        {mapTile === 'satellite' ? (
          <TileLayer
            url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
            attribution="Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community"
          />
        ) : (
          <TileLayer
            url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
            attribution="&copy; <a href='https://www.openstreetmap.org/copyright'>OpenStreetMap</a> contributors &copy; <a href='https://carto.com/attributions'>CARTO</a>"
          />
        )}

        {/* 1. Cadastral Boundary Layer */}
        {activeLayers.cadastral && (
          <LayerGroup>
            {parcels.map((parcel) => {
              const isSelected = parcel.parcel_id === selectedParcelId;
              const color = activeLayers.conflicts ? getPriorityColor(parcel.priority) : '#3b82f6';
              
              return (
                <Polygon
                  key={`cadastral-${parcel.parcel_id}`}
                  positions={parcel.coordinates}
                  pathOptions={{
                    color: isSelected ? '#38bdf8' : color,
                    weight: isSelected ? 4 : 2.5,
                    fillColor: color,
                    fillOpacity: isSelected ? 0.45 : 0.25,
                    dashArray: parcel.geometry_conflict ? '6, 6' : undefined
                  }}
                  eventHandlers={{
                    click: () => onSelectParcel(parcel.parcel_id)
                  }}
                >
                  <Tooltip sticky direction="top" className="custom-leaflet-tooltip">
                    <div className="p-1 font-sans">
                      <div className="font-bold text-slate-900">Parcel #{parcel.parcel_id} (Surv {parcel.survey_number})</div>
                      <div className="text-xs text-slate-600">Owner: {parcel.owner_name}</div>
                      <div className="text-xs font-semibold text-emerald-700 mt-1">Confidence Score: {parcel.confidence}%</div>
                    </div>
                  </Tooltip>
                </Polygon>
              );
            })}
          </LayerGroup>
        )}

        {/* 2. Drone ORI Visual Overlay Layer */}
        {activeLayers.drone_ori && (
          <LayerGroup>
            {parcels.map((parcel) => {
              if (!parcel.drone_coordinates) return null;
              return (
                <Polygon
                  key={`drone-${parcel.parcel_id}`}
                  positions={parcel.drone_coordinates}
                  pathOptions={{
                    color: '#10b981',
                    weight: 2,
                    fillColor: '#10b981',
                    fillOpacity: droneOpacity * 0.35,
                    dashArray: '3, 3'
                  }}
                />
              );
            })}
          </LayerGroup>
        )}

        {/* 3. Ground Truthing GNSS Survey Points */}
        {activeLayers.ground_truthing && (
          <LayerGroup>
            {parcels.flatMap((parcel) =>
              (parcel.ground_truthing_points || []).map((pt) => (
                <CircleMarker
                  key={`gt-${pt.id}`}
                  center={[pt.lat, pt.lng]}
                  radius={6}
                  pathOptions={{
                    color: '#06b6d4',
                    fillColor: '#22d3ee',
                    fillOpacity: 0.9,
                    weight: 2
                  }}
                >
                  <Popup>
                    <div className="p-1 font-sans text-xs">
                      <div className="font-bold text-cyan-900">GNSS Survey Point</div>
                      <div>ID: {pt.id}</div>
                      <div>Accuracy: {pt.accuracy_cm} cm</div>
                      <div>Date: {pt.timestamp}</div>
                    </div>
                  </Popup>
                </CircleMarker>
              ))
            )}
          </LayerGroup>
        )}

      </MapContainer>

      {/* Quick Legend Overlay */}
      <div className="absolute bottom-4 right-4 z-[1000] bg-slate-900/90 backdrop-blur-md p-3 rounded-xl border border-slate-700 text-xs text-slate-300 shadow-xl space-y-1.5">
        <div className="font-semibold text-slate-200 border-b border-slate-700 pb-1 flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" /> Reconciliation Priority
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-rose-500"></span>
          <span>HIGH (Field Survey Req)</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-amber-500"></span>
          <span>MEDIUM (Desk Audit)</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
          <span>LOW (Auto-Harmonized)</span>
        </div>
      </div>

    </div>
  );
}
