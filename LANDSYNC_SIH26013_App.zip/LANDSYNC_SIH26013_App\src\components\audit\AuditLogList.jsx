import React from 'react';
import { useFleet } from '../../context/FleetContext';
import { History, ShieldCheck, User } from 'lucide-react';

export const AuditLogList = () => {
  const { auditLogs } = useFleet();

  return (
    <div className="space-y-5 pb-20">
      <div>
        <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
          <History className="w-6 h-6 text-purple-400" />
          <span>System Audit Trail & Mutation History</span>
        </h2>
        <p className="text-xs text-slate-400">
          Immutable system audit log tracking all user actions, logins, vehicle modifications & dispatch updates.
        </p>
      </div>

      <div className="glass-card rounded-2xl border border-slate-700/60 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-900/80 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
              <tr>
                <th className="p-3">Log ID</th>
                <th className="p-3">User</th>
                <th className="p-3">Action</th>
                <th className="p-3">Target Entity</th>
                <th className="p-3">Mutation Details</th>
                <th className="p-3">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {auditLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-800/40 transition">
                  <td className="p-3 font-bold text-purple-400">{log.id}</td>
                  <td className="p-3 font-semibold text-white flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-blue-400" />
                    <span>{log.userName}</span>
                  </td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                      {log.action}
                    </span>
                  </td>
                  <td className="p-3 text-slate-300 font-semibold">{log.entity} ({log.entityId})</td>
                  <td className="p-3 text-slate-200">{log.details}</td>
                  <td className="p-3 text-slate-400 text-[11px]">{log.timestamp}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
