import React, { useState } from 'react';
import { useFleet } from '../../context/FleetContext';
import { formatCurrency, formatNumber } from '../../utils/formatters';
import { Fuel, Plus, Search, AlertCircle, FileText } from 'lucide-react';

export const FuelView = ({ onOpenAddFuel }) => {
  const { fuel, vehicles, drivers } = useFleet();
  const [searchQuery, setSearchQuery] = useState('');

  const filteredFuel = fuel.filter((f) => {
    const veh = vehicles.find((v) => v.id === f.vehicleId);
    return (
      f.fuelStation.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (veh && veh.regNo.toLowerCase().includes(searchQuery.toLowerCase()))
    );
  });

  const totalLitres = fuel.reduce((acc, f) => acc + (f.litres || 0), 0);
  const totalCost = fuel.reduce((acc, f) => acc + (f.totalCost || 0), 0);
  const avgPrice = fuel.length > 0 ? (totalCost / totalLitres).toFixed(2) : 0;

  return (
    <div className="space-y-5 pb-20">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
            <Fuel className="w-6 h-6 text-amber-400" />
            <span>Fuel Ledger & Consumption ({fuel.length})</span>
          </h2>
          <p className="text-xs text-slate-400">
            Track fuel purchases, price/L, fuel station receipts & mileage telemetry.
          </p>
        </div>

        <button
          onClick={onOpenAddFuel}
          className="px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-amber-600/30 transition"
        >
          <Plus className="w-4 h-4" />
          <span>Log Fuel Fill Up</span>
        </button>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="glass-card rounded-xl p-4 border border-amber-500/30">
          <div className="text-xs text-slate-400">Total Fuel Spend</div>
          <div className="text-xl font-black text-amber-400 mt-1">{formatCurrency(totalCost)}</div>
        </div>
        <div className="glass-card rounded-xl p-4 border border-slate-700/60">
          <div className="text-xs text-slate-400">Total Volume Filled</div>
          <div className="text-xl font-black text-white mt-1">{formatNumber(totalLitres)} Litres</div>
        </div>
        <div className="glass-card rounded-xl p-4 border border-slate-700/60">
          <div className="text-xs text-slate-400">Average Price Per Litre</div>
          <div className="text-xl font-black text-emerald-400 mt-1">₹{avgPrice} / L</div>
        </div>
      </div>

      {/* Fuel Ledger Table */}
      <div className="glass-card rounded-2xl border border-slate-700/60 overflow-hidden">
        <div className="p-4 border-b border-slate-700/60">
          <input
            type="text"
            placeholder="Search fuel station or registration number..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full glass-input rounded-xl px-3 py-2 text-xs"
          />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-900/80 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
              <tr>
                <th className="p-3">Vehicle</th>
                <th className="p-3">Date</th>
                <th className="p-3">Station</th>
                <th className="p-3">Litres</th>
                <th className="p-3">Price/L</th>
                <th className="p-3">Total Cost</th>
                <th className="p-3">Odometer</th>
                <th className="p-3">Receipt</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredFuel.map((f) => {
                const veh = vehicles.find((v) => v.id === f.vehicleId);
                return (
                  <tr key={f.id} className="hover:bg-slate-800/40 transition">
                    <td className="p-3 font-bold text-white">{veh ? veh.regNo : f.vehicleId}</td>
                    <td className="p-3">{f.date}</td>
                    <td className="p-3 font-semibold text-slate-200">{f.fuelStation}</td>
                    <td className="p-3">{f.litres} L</td>
                    <td className="p-3">₹{f.pricePerLitre}</td>
                    <td className="p-3 font-bold text-amber-400">{formatCurrency(f.totalCost)}</td>
                    <td className="p-3">{formatNumber(f.odometer)} KM</td>
                    <td className="p-3">
                      {f.receiptPhoto ? (
                        <a href={f.receiptPhoto} target="_blank" rel="noreferrer" className="text-blue-400 hover:underline flex items-center gap-1 font-bold">
                          <FileText className="w-3.5 h-3.5" /> View
                        </a>
                      ) : (
                        <span className="text-slate-500">None</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
