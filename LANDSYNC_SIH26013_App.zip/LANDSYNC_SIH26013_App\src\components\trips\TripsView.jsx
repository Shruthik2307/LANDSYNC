import React, { useState } from 'react';
import { useFleet } from '../../context/FleetContext';
import { useAuth } from '../../context/AuthContext';
import { formatCurrency, getTripStatusColor, formatDate } from '../../utils/formatters';
import {
  MapPin,
  Plus,
  Play,
  CheckCircle,
  Clock,
  Navigation,
  DollarSign,
  UserCheck,
  Truck,
  Filter,
  Search,
  CheckCircle2,
  XCircle
} from 'lucide-react';

export const TripsView = ({ onOpenAddTrip }) => {
  const { trips, vehicles, drivers, updateTripStatus } = useFleet();
  const { currentUser } = useAuth();

  const [statusFilter, setStatusFilter] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [endingOdometerModal, setEndingOdometerModal] = useState(null);
  const [endOdoInput, setEndOdoInput] = useState('');

  const filteredTrips = trips.filter((t) => {
    const vehicle = vehicles.find((v) => v.id === t.vehicleId);
    const driver = drivers.find((d) => d.id === t.driverId);
    const matchesSearch =
      t.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.startLocation.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.destination.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (vehicle && vehicle.regNo.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (driver && driver.fullName.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesStatus = statusFilter === 'All' || t.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const statuses = ['All', 'Scheduled', 'Started', 'In Progress', 'Completed', 'Cancelled'];

  const handleCompleteClick = (trip) => {
    const currentVeh = vehicles.find((v) => v.id === trip.vehicleId);
    const startOdo = trip.startOdometer || currentVeh?.currentOdometer || 0;
    setEndOdoInput(startOdo + 150); // Default estimate
    setEndingOdometerModal(trip);
  };

  const handleCompleteSubmit = (e) => {
    e.preventDefault();
    if (!endingOdometerModal) return;
    const endOdo = Number(endOdoInput);
    if (endOdo < endingOdometerModal.startOdometer) {
      alert(`Ending Odometer (${endOdo}) cannot be less than Starting Odometer (${endingOdometerModal.startOdometer})!`);
      return;
    }

    updateTripStatus(endingOdometerModal.id, 'Completed', { endOdometer: endOdo });
    setEndingOdometerModal(null);
  };

  return (
    <div className="space-y-5 pb-20">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
            <MapPin className="w-6 h-6 text-purple-400" />
            <span>Trip Dispatch & Workflow ({trips.length})</span>
          </h2>
          <p className="text-xs text-slate-400">
            Monitor real-time freight dispatches, distance logs & trip profitability.
          </p>
        </div>

        {currentUser.role !== 'Driver' && (
          <button
            onClick={onOpenAddTrip}
            className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-purple-600/30 transition"
          >
            <Plus className="w-4 h-4" />
            <span>Dispatch New Trip</span>
          </button>
        )}
      </div>

      {/* Search & Filter */}
      <div className="glass-card rounded-2xl p-4 border border-slate-700/60 space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Search by trip ID, customer, route, vehicle reg or driver..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full glass-input rounded-xl pl-10 pr-4 py-2.5 text-xs placeholder:text-slate-500"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          <span className="text-[11px] text-slate-400 font-semibold mr-1 flex items-center gap-1">
            <Filter className="w-3 h-3" />
            Workflow Status:
          </span>
          {statuses.map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition ${
                statusFilter === st
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700/60'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Trips Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredTrips.map((trip) => {
          const vehicle = vehicles.find((v) => v.id === trip.vehicleId);
          const driver = drivers.find((d) => d.id === trip.driverId);
          const profit = (trip.revenue || 0) - (trip.expenses || 0);
          const statusColor = getTripStatusColor(trip.status);

          return (
            <div
              key={trip.id}
              className="glass-card rounded-2xl p-5 border border-slate-700/60 flex flex-col justify-between space-y-4"
            >
              <div>
                {/* Top Row */}
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="text-[11px] font-bold text-purple-400 bg-purple-500/10 px-2 py-0.5 rounded border border-purple-500/20">
                      {trip.id}
                    </span>
                    <h3 className="text-sm font-extrabold text-white mt-1">
                      {trip.customerName}
                    </h3>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-bold border ${statusColor}`}>
                    {trip.status}
                  </span>
                </div>

                {/* Route Visualizer */}
                <div className="mt-3 p-3 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
                  <div className="flex items-center gap-2 text-xs">
                    <div className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                    <span className="text-slate-300 font-semibold truncate">{trip.startLocation}</span>
                  </div>
                  <div className="pl-1 border-l-2 border-dashed border-slate-700 ml-1 py-1 text-[10px] text-slate-400 flex items-center gap-2">
                    <Navigation className="w-3 h-3 text-purple-400" />
                    <span>Estimated Distance: {trip.distanceKm} KM</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <div className="w-2.5 h-2.5 rounded-full bg-rose-400" />
                    <span className="text-slate-300 font-semibold truncate">{trip.destination}</span>
                  </div>
                </div>

                {/* Vehicle & Driver Info */}
                <div className="grid grid-cols-2 gap-2 mt-3 text-xs text-slate-400">
                  <div className="flex items-center gap-1.5">
                    <Truck className="w-3.5 h-3.5 text-blue-400" />
                    <span className="font-semibold text-slate-200">{vehicle ? vehicle.regNo : 'Unassigned'}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="font-semibold text-slate-200">{driver ? driver.fullName : 'Unassigned'}</span>
                  </div>
                </div>

                {/* Financial Profitability */}
                <div className="mt-3 p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/50 flex items-center justify-between text-xs">
                  <div>
                    <span className="text-slate-400 text-[10px]">Revenue:</span>{' '}
                    <span className="font-bold text-emerald-400">{formatCurrency(trip.revenue)}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px]">Trip Spend:</span>{' '}
                    <span className="font-bold text-rose-400">{formatCurrency(trip.expenses)}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px]">Est Profit:</span>{' '}
                    <span className={`font-black ${profit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {formatCurrency(profit)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Workflow Actions */}
              <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2">
                {trip.status === 'Scheduled' && (
                  <button
                    onClick={() => updateTripStatus(trip.id, 'Started')}
                    className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 transition"
                  >
                    <Play className="w-3.5 h-3.5" />
                    <span>Start Trip</span>
                  </button>
                )}

                {(trip.status === 'Started' || trip.status === 'In Progress') && (
                  <>
                    <button
                      onClick={() => updateTripStatus(trip.id, 'In Progress')}
                      className="px-3 py-1.5 rounded-xl bg-purple-600/40 hover:bg-purple-600/60 text-purple-200 text-xs font-bold border border-purple-500/40 transition"
                    >
                      In Progress
                    </button>
                    <button
                      onClick={() => handleCompleteClick(trip)}
                      className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-emerald-600/30 transition"
                    >
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>Complete Trip</span>
                    </button>
                  </>
                )}

                {trip.status === 'Completed' && (
                  <span className="text-xs text-emerald-400 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4" />
                    Completed ({trip.distanceKm} KM)
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Complete Trip Odometer Modal */}
      {endingOdometerModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="w-full max-w-md glass-panel rounded-2xl p-5 border border-slate-700/80 space-y-4 animate-fade-in">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-emerald-400" />
              Complete Trip & Log Ending Odometer
            </h3>
            <p className="text-xs text-slate-300">
              Starting Odometer: <span className="font-bold text-white">{endingOdometerModal.startOdometer} KM</span>
            </p>
            <form onSubmit={handleCompleteSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Ending Odometer Reading (KM) *</label>
                <input
                  type="number"
                  required
                  min={endingOdometerModal.startOdometer}
                  value={endOdoInput}
                  onChange={(e) => setEndOdoInput(e.target.value)}
                  className="w-full glass-input rounded-xl px-3 py-2.5 text-sm font-bold text-emerald-400"
                />
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEndingOdometerModal(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 text-white font-bold shadow-lg shadow-emerald-600/30"
                >
                  Finish Trip & Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
