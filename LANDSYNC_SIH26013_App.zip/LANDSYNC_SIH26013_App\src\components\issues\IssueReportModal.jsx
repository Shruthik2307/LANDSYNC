import React, { useState } from 'react';
import { useFleet } from '../../context/FleetContext';
import { useAuth } from '../../context/AuthContext';
import { X, AlertTriangle } from 'lucide-react';

export const IssueReportModal = ({ onClose, onSave }) => {
  const { vehicles, drivers } = useFleet();
  const { currentUser } = useAuth();

  const [formData, setFormData] = useState({
    vehicleId: vehicles[0]?.id || '',
    driverId: currentUser.driverId || drivers[0]?.id || '',
    category: 'Brakes',
    severity: 'High',
    description: '',
    photo: 'https://images.unsplash.com/photo-1486006920555-c77dce18193b?w=400&auto=format&fit=crop&q=80',
    notes: ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.description) {
      alert('Please describe the vehicle issue.');
      return;
    }
    onSave(formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-3 sm:p-5">
      <div className="w-full max-w-md glass-panel rounded-2xl border border-slate-700/80 p-5 shadow-2xl animate-fade-in max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between pb-4 border-b border-slate-700/60">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-rose-500/20 text-rose-400">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Report Vehicle Defect</h2>
              <p className="text-xs text-slate-400">Notify Fleet Manager of mechanical or electrical issues</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto pt-4 space-y-3 text-xs pr-1">
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Select Affected Vehicle *</label>
            <select
              value={formData.vehicleId}
              onChange={(e) => setFormData({ ...formData, vehicleId: e.target.value })}
              className="w-full glass-input rounded-xl px-3 py-2 bg-slate-900"
            >
              {vehicles.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.regNo} ({v.make} {v.model})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Issue Category *</label>
            <select
              value={formData.category}
              onChange={(e) => setFormData({ ...formData, category: e.target.value })}
              className="w-full glass-input rounded-xl px-3 py-2 bg-slate-900"
            >
              <option value="Brakes">Brakes</option>
              <option value="Engine">Engine / Clutch</option>
              <option value="Tyre">Tyre / Wheel Alignment</option>
              <option value="Electrical">Electrical / Battery</option>
              <option value="AC / Cabin">AC / Cabin Climate</option>
              <option value="Body Damage">Body / Accident Damage</option>
              <option value="Other">Other Defect</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Severity Level *</label>
            <select
              value={formData.severity}
              onChange={(e) => setFormData({ ...formData, severity: e.target.value })}
              className="w-full glass-input rounded-xl px-3 py-2 bg-slate-900 font-bold"
            >
              <option value="Low">Low (Can drive to workshop)</option>
              <option value="Medium">Medium (Attention needed soon)</option>
              <option value="High">High (Immediate inspection required)</option>
              <option value="Critical">Critical (Unsafe to operate vehicle)</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Issue Description *</label>
            <textarea
              required
              rows={3}
              placeholder="Describe symptoms, noise, warning lights or pedal feel..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full glass-input rounded-xl px-3 py-2"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-700/60">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold shadow-lg shadow-rose-600/30"
            >
              Submit Defect Report
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
