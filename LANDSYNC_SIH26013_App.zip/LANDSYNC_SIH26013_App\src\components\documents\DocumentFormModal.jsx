import React, { useState } from 'react';
import { useFleet } from '../../context/FleetContext';
import { X, FileText, Upload } from 'lucide-react';

export const DocumentFormModal = ({ onClose, onSave }) => {
  const { vehicles, drivers } = useFleet();

  const [formData, setFormData] = useState({
    docType: 'Insurance Policy',
    entityType: 'Vehicle',
    entityId: vehicles[0]?.id || '',
    docNumber: 'POL-ICICI-2026-99',
    issueDate: new Date().toISOString().slice(0, 10),
    expiryDate: new Date(Date.now() + 31536000000).toISOString().slice(0, 10), // 1 year
    fileUrl: 'https://images.unsplash.com/photo-1568269843937-25e225916694?w=600&auto=format&fit=crop&q=80',
    notes: ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.docNumber || !formData.docType) {
      alert('Please fill in document number and type.');
      return;
    }
    onSave(formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-3 sm:p-5">
      <div className="w-full max-w-lg glass-panel rounded-2xl border border-slate-700/80 p-5 shadow-2xl animate-fade-in max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between pb-4 border-b border-slate-700/60">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Upload Fleet Document</h2>
              <p className="text-xs text-slate-400">Store RC, Insurance, Permit or Driver License</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto pt-4 space-y-3 text-xs pr-1">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Document Type *</label>
              <select
                value={formData.docType}
                onChange={(e) => setFormData({ ...formData, docType: e.target.value })}
                className="w-full glass-input rounded-xl px-3 py-2 bg-slate-900"
              >
                <option value="Registration Certificate (RC)">Registration Certificate (RC)</option>
                <option value="Insurance Policy">Insurance Policy</option>
                <option value="Pollution Certificate (PUC)">Pollution Certificate (PUC)</option>
                <option value="National Permit">National Permit</option>
                <option value="Fitness Certificate">Fitness Certificate</option>
                <option value="Driver License">Driver License</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Target Entity *</label>
              <select
                value={formData.entityType}
                onChange={(e) => {
                  const type = e.target.value;
                  const firstId = type === 'Vehicle' ? vehicles[0]?.id : drivers[0]?.id;
                  setFormData({ ...formData, entityType: type, entityId: firstId || '' });
                }}
                className="w-full glass-input rounded-xl px-3 py-2 bg-slate-900"
              >
                <option value="Vehicle">Vehicle</option>
                <option value="Driver">Driver</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Select Target {formData.entityType} *</label>
              <select
                value={formData.entityId}
                onChange={(e) => setFormData({ ...formData, entityId: e.target.value })}
                className="w-full glass-input rounded-xl px-3 py-2 bg-slate-900"
              >
                {formData.entityType === 'Vehicle'
                  ? vehicles.map((v) => (
                      <option key={v.id} value={v.id}>
                        {v.regNo} ({v.make})
                      </option>
                    ))
                  : drivers.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.fullName}
                      </option>
                    ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Document / Certificate No *</label>
              <input
                type="text"
                required
                placeholder="e.g. POL-ICICI-998124"
                value={formData.docNumber}
                onChange={(e) => setFormData({ ...formData, docNumber: e.target.value })}
                className="w-full glass-input rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Issue Date</label>
              <input
                type="date"
                value={formData.issueDate}
                onChange={(e) => setFormData({ ...formData, issueDate: e.target.value })}
                className="w-full glass-input rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Expiry Date *</label>
              <input
                type="date"
                required
                value={formData.expiryDate}
                onChange={(e) => setFormData({ ...formData, expiryDate: e.target.value })}
                className="w-full glass-input rounded-xl px-3 py-2"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Notes / Coverage Details</label>
            <input
              type="text"
              placeholder="e.g. ₹50 Lakh third party liability cover..."
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              className="w-full glass-input rounded-xl px-3 py-2"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-700/60">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold shadow-lg shadow-emerald-600/30"
            >
              Upload Document
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
