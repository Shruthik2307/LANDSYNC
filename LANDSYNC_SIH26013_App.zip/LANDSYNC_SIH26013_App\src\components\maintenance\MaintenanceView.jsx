import React, { useState } from 'react';
import { useFleet } from '../../context/FleetContext';
import { formatCurrency } from '../../utils/formatters';
import { Wrench, Plus, Search, CheckCircle2, Clock } from 'lucide-react';

export const MaintenanceView = ({ onOpenAddMaintenance }) => {
  const { maintenance, vehicles } = useFleet();
  const [searchQuery, setSearchQuery] = useState('');

  const filtered = maintenance.filter((m) => {
    const veh = vehicles.find((v) => v.id === m.vehicleId);
    return (
      m.serviceType.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.serviceProvider.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (veh && veh.regNo.toLowerCase().includes(searchQuery.toLowerCase()))
    );
  });

  return (
    <div className="space-y-5 pb-20">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
            <Wrench className="w-6 h-6 text-blue-400" />
            <span>Maintenance & Servicing Hub ({maintenance.length})</span>
          </h2>
          <p className="text-xs text-slate-400">
            Preventive service scheduling, repairs, labor vs parts cost breakdowns.
          </p>
        </div>

        <button
          onClick={onOpenAddMaintenance}
          className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-blue-600/30 transition"
        >
          <Plus className="w-4 h-4" />
          <span>Schedule Service</span>
        </button>
      </div>

      <div className="glass-card rounded-2xl p-4 border border-slate-700/60">
        <input
          type="text"
          placeholder="Search by service type, provider or vehicle reg..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full glass-input rounded-xl px-3 py-2 text-xs"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((m) => {
          const veh = vehicles.find((v) => v.id === m.vehicleId);
          return (
            <div key={m.id} className="glass-card rounded-2xl p-4 border border-slate-700/60 space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[10px] font-bold text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded">
                    {m.id}
                  </span>
                  <h3 className="text-sm font-bold text-white mt-1">{m.serviceType}</h3>
                  <div className="text-xs text-slate-400">
                    Target Vehicle: <span className="text-white font-semibold">{veh ? veh.regNo : m.vehicleId}</span>
                  </div>
                </div>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                  {m.status}
                </span>
              </div>

              <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-xs space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-400">Service Provider:</span>
                  <span className="font-semibold text-slate-200">{m.serviceProvider}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Parts Replaced:</span>
                  <span className="font-semibold text-slate-300 truncate max-w-[200px]">{m.partsReplaced}</span>
                </div>
                <div className="flex justify-between pt-1 border-t border-slate-800">
                  <span className="text-slate-400">Labor: ₹{m.labourCost} | Parts: ₹{m.partsCost}</span>
                  <span className="font-bold text-blue-400">Total: {formatCurrency(m.totalCost)}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
