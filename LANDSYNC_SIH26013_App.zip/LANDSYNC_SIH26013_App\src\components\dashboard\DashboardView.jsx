import React from 'react';
import { useFleet } from '../../context/FleetContext';
import { useAuth } from '../../context/AuthContext';
import { formatCurrency, formatNumber, getDaysRemaining } from '../../utils/formatters';
import {
  Truck,
  Users,
  MapPin,
  Fuel,
  Wrench,
  DollarSign,
  AlertTriangle,
  CheckCircle2,
  TrendingUp,
  PlusCircle,
  Clock,
  ChevronRight,
  ShieldAlert
} from 'lucide-react';

export const DashboardView = ({ setActiveTab, onOpenAddVehicle, onOpenAddTrip, onOpenAddFuel, onOpenReportIssue }) => {
  const { vehicles, drivers, trips, fuel, maintenance, expenses, documents, issues } = useFleet();
  const { currentUser } = useAuth();

  // Metrics calculation
  const totalVehicles = vehicles.length;
  const availableVehicles = vehicles.filter((v) => v.status === 'Available').length;
  const onTripVehicles = vehicles.filter((v) => v.status === 'On Trip').length;
  const maintenanceVehicles = vehicles.filter((v) => v.status === 'Maintenance').length;
  const inactiveVehicles = vehicles.filter((v) => v.status === 'Inactive').length;

  const totalDrivers = drivers.length;
  const activeTrips = trips.filter((t) => t.status === 'In Progress' || t.status === 'Started').length;
  const completedTrips = trips.filter((t) => t.status === 'Completed').length;

  const totalRevenue = trips.reduce((acc, t) => acc + (t.revenue || 0), 0);
  const totalExpenses = expenses.reduce((acc, e) => acc + (e.amount || 0), 0);
  const totalFuelCost = fuel.reduce((acc, f) => acc + (f.totalCost || 0), 0);
  const totalMaintenanceCost = maintenance.reduce((acc, m) => acc + (m.totalCost || 0), 0);
  const netProfit = totalRevenue - totalExpenses;

  const totalDistance = trips.reduce((acc, t) => acc + (t.distanceKm || 0), 0);
  const totalFuelLitres = fuel.reduce((acc, f) => acc + (f.litres || 0), 0);

  // Expiring alerts
  const expiringDocs = documents.filter((d) => getDaysRemaining(d.expiryDate) <= 30);
  const criticalIssues = issues.filter((i) => i.status !== 'Resolved');

  return (
    <div className="space-y-6 pb-20">
      {/* Welcome Banner */}
      <div className="glass-card rounded-2xl p-5 border border-blue-500/20 relative overflow-hidden">
        <div className="absolute -right-10 -bottom-10 w-48 h-48 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-blue-400 font-semibold px-2 py-0.5 rounded-md bg-blue-500/10 border border-blue-500/20">
                {currentUser.role} Control Desk
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white mt-1">
              Welcome back, {currentUser.name} 👋
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
              Live fleet operations, financial analytics & driver assignment monitoring.
            </p>
          </div>

          {/* Quick Action Bar */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={onOpenAddTrip}
              className="px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-blue-600/30 transition"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Create Trip</span>
            </button>
            <button
              onClick={onOpenAddFuel}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition"
            >
              <Fuel className="w-4 h-4 text-emerald-400" />
              <span>Log Fuel</span>
            </button>
            <button
              onClick={onOpenReportIssue}
              className="px-3 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 text-xs font-bold flex items-center gap-1.5 transition"
            >
              <AlertTriangle className="w-4 h-4 text-rose-400" />
              <span>Report Issue</span>
            </button>
          </div>
        </div>
      </div>

      {/* Fleet KPI Grid */}
      <div>
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
          Fleet & Vehicle Summary
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <div
            onClick={() => setActiveTab('vehicles')}
            className="glass-card rounded-xl p-3.5 border border-slate-700/60 cursor-pointer hover:border-blue-500/50 transition"
          >
            <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
              <span>Total Vehicles</span>
              <Truck className="w-4 h-4 text-blue-400" />
            </div>
            <div className="text-2xl font-black text-white mt-2">{totalVehicles}</div>
            <div className="text-[10px] text-slate-400 mt-1">Active registered units</div>
          </div>

          <div
            onClick={() => setActiveTab('vehicles')}
            className="glass-card rounded-xl p-3.5 border border-slate-700/60 cursor-pointer hover:border-emerald-500/50 transition"
          >
            <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
              <span>Available</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-2xl font-black text-emerald-400 mt-2">{availableVehicles}</div>
            <div className="text-[10px] text-emerald-400/80 mt-1">Ready for dispatch</div>
          </div>

          <div
            onClick={() => setActiveTab('vehicles')}
            className="glass-card rounded-xl p-3.5 border border-slate-700/60 cursor-pointer hover:border-purple-500/50 transition"
          >
            <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
              <span>On Trip</span>
              <MapPin className="w-4 h-4 text-purple-400" />
            </div>
            <div className="text-2xl font-black text-purple-400 mt-2">{onTripVehicles}</div>
            <div className="text-[10px] text-purple-400/80 mt-1">Currently active</div>
          </div>

          <div
            onClick={() => setActiveTab('vehicles')}
            className="glass-card rounded-xl p-3.5 border border-slate-700/60 cursor-pointer hover:border-amber-500/50 transition"
          >
            <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
              <span>Maintenance</span>
              <Wrench className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-2xl font-black text-amber-400 mt-2">{maintenanceVehicles}</div>
            <div className="text-[10px] text-amber-400/80 mt-1">In workshop</div>
          </div>

          <div
            onClick={() => setActiveTab('vehicles')}
            className="glass-card rounded-xl p-3.5 border border-slate-700/60 cursor-pointer hover:border-rose-500/50 transition"
          >
            <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
              <span>Inactive</span>
              <Clock className="w-4 h-4 text-rose-400" />
            </div>
            <div className="text-2xl font-black text-rose-400 mt-2">{inactiveVehicles}</div>
            <div className="text-[10px] text-rose-400/80 mt-1">Off road</div>
          </div>

          <div
            onClick={() => setActiveTab('drivers')}
            className="glass-card rounded-xl p-3.5 border border-slate-700/60 cursor-pointer hover:border-indigo-500/50 transition"
          >
            <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
              <span>Drivers</span>
              <Users className="w-4 h-4 text-indigo-400" />
            </div>
            <div className="text-2xl font-black text-white mt-2">{totalDrivers}</div>
            <div className="text-[10px] text-slate-400 mt-1">Registered drivers</div>
          </div>
        </div>
      </div>

      {/* Financial Summary */}
      <div>
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
          Financial & Revenue Analytics (₹ INR)
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="glass-card rounded-xl p-4 border border-blue-500/30">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span>Total Fleet Revenue</span>
              <TrendingUp className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-2xl font-black text-white mt-2">{formatCurrency(totalRevenue)}</div>
            <div className="text-[10px] text-emerald-400 mt-1">Gross earnings from trips</div>
          </div>

          <div className="glass-card rounded-xl p-4 border border-rose-500/30">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span>Total Operating Expenses</span>
              <DollarSign className="w-4 h-4 text-rose-400" />
            </div>
            <div className="text-2xl font-black text-rose-400 mt-2">{formatCurrency(totalExpenses)}</div>
            <div className="text-[10px] text-slate-400 mt-1">Fuel, maintenance, tolls & permits</div>
          </div>

          <div className="glass-card rounded-xl p-4 border border-emerald-500/30">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span>Net Profitability</span>
              <TrendingUp className="w-4 h-4 text-emerald-400" />
            </div>
            <div className={`text-2xl font-black mt-2 ${netProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {formatCurrency(netProfit)}
            </div>
            <div className="text-[10px] text-slate-400 mt-1">Revenue minus all expenses</div>
          </div>

          <div className="glass-card rounded-xl p-4 border border-slate-700/60">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span>Fuel vs Servicing Spend</span>
              <Fuel className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-sm font-bold text-slate-200 mt-2">
              Fuel: <span className="text-amber-400">{formatCurrency(totalFuelCost)}</span>
            </div>
            <div className="text-xs text-slate-400 mt-0.5">
              Service: <span className="text-blue-400">{formatCurrency(totalMaintenanceCost)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Operational Summary & Distance */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Operational Stats */}
        <div className="glass-card rounded-2xl p-5 border border-slate-700/60 space-y-4">
          <h4 className="text-sm font-bold text-white flex items-center gap-2">
            <MapPin className="w-4 h-4 text-blue-400" />
            <span>Operational Statistics</span>
          </h4>
          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/50">
              <span className="text-slate-400">Total Distance Logged</span>
              <span className="font-bold text-white text-sm">{formatNumber(totalDistance)} KM</span>
            </div>
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/50">
              <span className="text-slate-400">Total Fuel Consumed</span>
              <span className="font-bold text-amber-400 text-sm">{formatNumber(totalFuelLitres)} Litres</span>
            </div>
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/50">
              <span className="text-slate-400">Completed Trips</span>
              <span className="font-bold text-emerald-400 text-sm">{completedTrips} Trips</span>
            </div>
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/50">
              <span className="text-slate-400">Active / In Progress</span>
              <span className="font-bold text-purple-400 text-sm">{activeTrips} Trips</span>
            </div>
          </div>
        </div>

        {/* Expiring Alerts Center */}
        <div className="lg:col-span-2 glass-card rounded-2xl p-5 border border-amber-500/30">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              <span>Critical Urgency Alerts ({expiringDocs.length + criticalIssues.length})</span>
            </h4>
            <button
              onClick={() => setActiveTab('documents')}
              className="text-xs text-blue-400 hover:text-blue-300 font-semibold flex items-center gap-1"
            >
              <span>View Vault</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
            {expiringDocs.map((doc) => {
              const days = getDaysRemaining(doc.expiryDate);
              const vehicle = vehicles.find((v) => v.id === doc.entityId);
              return (
                <div
                  key={doc.id}
                  className="p-3 rounded-xl bg-slate-800/80 border border-amber-500/30 flex items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-lg bg-amber-500/20 text-amber-400">
                      <AlertTriangle className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="font-bold text-white">
                        {doc.docType} ({doc.docNumber})
                      </div>
                      <div className="text-slate-400 text-[11px]">
                        Target: {vehicle ? `${vehicle.regNo} (${vehicle.make})` : doc.entityId}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${days < 0 ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'}`}>
                      {days < 0 ? 'EXPIRED' : `${days} days left`}
                    </span>
                  </div>
                </div>
              );
            })}

            {criticalIssues.map((iss) => (
              <div
                key={iss.id}
                className="p-3 rounded-xl bg-slate-800/80 border border-rose-500/30 flex items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-lg bg-rose-500/20 text-rose-400">
                    <Wrench className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-bold text-white">
                      Defect Reported: {iss.category} ({iss.severity})
                    </div>
                    <div className="text-slate-400 text-[11px]">
                      Vehicle: {iss.vehicleId} — Status: {iss.status}
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => setActiveTab('issues')}
                  className="px-2.5 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 text-[10px] font-bold border border-rose-500/30 transition"
                >
                  Resolve
                </button>
              </div>
            ))}

            {expiringDocs.length === 0 && criticalIssues.length === 0 && (
              <div className="text-center py-6 text-slate-400 text-xs">
                <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2 opacity-80" />
                All fleet documents valid & zero open vehicle issues!
              </div>
            )}
          </div>
        </div>
      </div>

      {/* SVG Interactive Analytics Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Cost per Vehicle Analytics Bar Chart */}
        <div className="glass-card rounded-2xl p-5 border border-slate-700/60 space-y-4">
          <h4 className="text-sm font-bold text-white flex items-center justify-between">
            <span>Vehicle Running Cost & Expense Breakdown</span>
            <span className="text-xs text-blue-400 font-normal">₹ Total Spend</span>
          </h4>

          <div className="space-y-3 pt-2">
            {vehicles.slice(0, 5).map((v) => {
              const vExpenses = expenses
                .filter((e) => e.vehicleId === v.id)
                .reduce((acc, e) => acc + (e.amount || 0), 0);
              const maxVal = 50000;
              const percent = Math.min(100, Math.round((vExpenses / maxVal) * 100));

              return (
                <div key={v.id} className="space-y-1 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-200">
                      {v.regNo} <span className="text-slate-400 font-normal">({v.make} {v.model})</span>
                    </span>
                    <span className="font-bold text-blue-400">{formatCurrency(vExpenses)}</span>
                  </div>
                  <div className="w-full h-2.5 rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-blue-500 to-indigo-500 transition-all duration-500"
                      style={{ width: `${Math.max(5, percent)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Expense Categories Distribution */}
        <div className="glass-card rounded-2xl p-5 border border-slate-700/60 space-y-4">
          <h4 className="text-sm font-bold text-white flex items-center justify-between">
            <span>Expense Category Allocation</span>
            <span className="text-xs text-slate-400 font-normal">% Share</span>
          </h4>

          <div className="grid grid-cols-2 gap-3 pt-2">
            {[
              { label: 'Fuel', amount: totalFuelCost, color: 'bg-amber-500' },
              { label: 'Maintenance', amount: totalMaintenanceCost, color: 'bg-blue-500' },
              { label: 'Tolls', amount: 3450, color: 'bg-purple-500' },
              { label: 'Permits', amount: 4200, color: 'bg-indigo-500' }
            ].map((cat) => {
              const share = totalExpenses > 0 ? Math.round((cat.amount / totalExpenses) * 100) : 0;
              return (
                <div key={cat.label} className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/50 space-y-1">
                  <div className="flex items-center gap-2 text-xs text-slate-300 font-semibold">
                    <div className={`w-2.5 h-2.5 rounded-full ${cat.color}`} />
                    <span>{cat.label}</span>
                  </div>
                  <div className="text-base font-bold text-white">{formatCurrency(cat.amount)}</div>
                  <div className="text-[10px] text-slate-400">{share}% of total spend</div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
