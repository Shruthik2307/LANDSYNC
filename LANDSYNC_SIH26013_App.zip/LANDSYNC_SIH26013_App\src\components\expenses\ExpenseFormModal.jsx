import React, { useState } from 'react';
import { useFleet } from '../../context/FleetContext';
import { X, CreditCard } from 'lucide-react';

export const ExpenseFormModal = ({ onClose, onSave }) => {
  const { vehicles, drivers } = useFleet();

  const [formData, setFormData] = useState({
    vehicleId: vehicles[0]?.id || '',
    driverId: drivers[0]?.id || '',
    category: 'Toll',
    amount: 1500,
    date: new Date().toISOString().slice(0, 10),
    paymentMethod: 'FASTag Auto-Debit',
    vendor: 'NHAI FASTag Hub',
    receiptPhoto: null,
    description: ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.amount || !formData.category) {
      alert('Please enter amount and category.');
      return;
    }
    onSave(formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-3 sm:p-5">
      <div className="w-full max-w-lg glass-panel rounded-2xl border border-slate-700/80 p-5 shadow-2xl animate-fade-in max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between pb-4 border-b border-slate-700/60">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-rose-500/20 text-rose-400">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Log Operational Expense</h2>
              <p className="text-xs text-slate-400">Enter expense amount, category & vendor info</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto pt-4 space-y-3 text-xs pr-1">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Expense Category *</label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full glass-input rounded-xl px-3 py-2 bg-slate-900"
              >
                <option value="Toll">FASTag Toll</option>
                <option value="Permit">Inter-state Permit</option>
                <option value="Parking">Yard / Port Parking</option>
                <option value="Driver Allowance">Driver Night Allowance</option>
                <option value="Repairs">Unscheduled Repairs</option>
                <option value="Other">Other Operational Spend</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Expense Amount (₹ INR) *</label>
              <input
                type="number"
                required
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: Number(e.target.value) })}
                className="w-full glass-input rounded-xl px-3 py-2 text-rose-400 font-bold"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Vehicle</label>
              <select
                value={formData.vehicleId}
                onChange={(e) => setFormData({ ...formData, vehicleId: e.target.value })}
                className="w-full glass-input rounded-xl px-3 py-2 bg-slate-900"
              >
                {vehicles.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.regNo} ({v.make})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Vendor / Provider Name</label>
              <input
                type="text"
                placeholder="e.g. NHAI FASTag / RTO Department"
                value={formData.vendor}
                onChange={(e) => setFormData({ ...formData, vendor: e.target.value })}
                className="w-full glass-input rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Expense Date</label>
              <input
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="w-full glass-input rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Payment Method</label>
              <select
                value={formData.paymentMethod}
                onChange={(e) => setFormData({ ...formData, paymentMethod: e.target.value })}
                className="w-full glass-input rounded-xl px-3 py-2 bg-slate-900"
              >
                <option value="FASTag Auto-Debit">FASTag Auto-Debit</option>
                <option value="Company Card">Company Credit Card</option>
                <option value="UPI Direct">UPI Direct</option>
                <option value="Net Banking">Net Banking</option>
                <option value="Cash">Cash</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Description / Notes</label>
            <input
              type="text"
              placeholder="Provide context or route details..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full glass-input rounded-xl px-3 py-2"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-700/60">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold shadow-lg shadow-rose-600/30"
            >
              Log Expense
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
