import React, { useState } from 'react';
import { useFleet } from '../../context/FleetContext';
import { useAuth } from '../../context/AuthContext';
import { formatCurrency, getVehicleStatusColor, formatNumber } from '../../utils/formatters';
import {
  Truck,
  Plus,
  Search,
  Filter,
  UserCheck,
  Calendar,
  Gauge,
  FileText,
  ChevronRight,
  ShieldCheck
} from 'lucide-react';

export const VehiclesView = ({ onOpenDetail, onOpenAdd }) => {
  const { vehicles, drivers } = useFleet();
  const { currentUser } = useAuth();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');

  const filteredVehicles = vehicles.filter((v) => {
    const driver = drivers.find((d) => d.id === v.assignedDriverId);
    const matchesSearch =
      v.regNo.toLowerCase().includes(searchQuery.toLowerCase()) ||
      v.make.toLowerCase().includes(searchQuery.toLowerCase()) ||
      v.model.toLowerCase().includes(searchQuery.toLowerCase()) ||
      v.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (driver && driver.fullName.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesStatus = statusFilter === 'All' || v.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const statuses = ['All', 'Available', 'Assigned', 'On Trip', 'Maintenance', 'Inactive'];

  return (
    <div className="space-y-5 pb-20">
      {/* Module Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
            <Truck className="w-6 h-6 text-blue-400" />
            <span>Vehicle Fleet Registry ({vehicles.length})</span>
          </h2>
          <p className="text-xs text-slate-400">
            Real-time vehicle status, driver assignments, telemetry & operational history.
          </p>
        </div>

        {currentUser.role !== 'Driver' && (
          <button
            onClick={onOpenAdd}
            className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-blue-600/30 transition"
          >
            <Plus className="w-4 h-4" />
            <span>Add Vehicle</span>
          </button>
        )}
      </div>

      {/* Search & Filter Bar */}
      <div className="glass-card rounded-2xl p-4 border border-slate-700/60 space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Search by registration number, make, model, type or driver..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full glass-input rounded-xl pl-10 pr-4 py-2.5 text-xs placeholder:text-slate-500"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          <span className="text-[11px] text-slate-400 font-semibold mr-1 flex items-center gap-1">
            <Filter className="w-3 h-3" />
            Status:
          </span>
          {statuses.map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition ${
                statusFilter === st
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700/60'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Vehicles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredVehicles.map((vehicle) => {
          const driver = drivers.find((d) => d.id === vehicle.assignedDriverId);
          const statusClass = getVehicleStatusColor(vehicle.status);

          return (
            <div
              key={vehicle.id}
              onClick={() => onOpenDetail(vehicle)}
              className="glass-card rounded-2xl border border-slate-700/60 overflow-hidden cursor-pointer hover:border-blue-500/50 transition group flex flex-col justify-between"
            >
              {/* Image & Header */}
              <div>
                <div className="relative h-40 w-full overflow-hidden bg-slate-900">
                  <img
                    src={vehicle.photo}
                    alt={vehicle.regNo}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-500 opacity-90"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent" />

                  {/* Status Badge */}
                  <span className={`absolute top-3 right-3 px-3 py-1 rounded-full text-[11px] font-extrabold border ${statusClass}`}>
                    {vehicle.status}
                  </span>

                  <span className="absolute bottom-3 left-3 text-lg font-black text-white tracking-wider">
                    {vehicle.regNo}
                  </span>
                </div>

                {/* Details */}
                <div className="p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">
                      {vehicle.make} {vehicle.model}
                    </span>
                    <span className="text-[11px] px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 border border-slate-700">
                      {vehicle.type}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-400 pt-1">
                    <div className="flex items-center gap-1.5">
                      <Gauge className="w-3.5 h-3.5 text-blue-400" />
                      <span>{formatNumber(vehicle.currentOdometer)} KM</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="truncate">{driver ? driver.fullName : 'Unassigned'}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Year: {vehicle.year}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5 text-amber-400" />
                      <span>Fuel: {vehicle.fuelType}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Card Footer */}
              <div className="px-4 py-3 bg-slate-900/60 border-t border-slate-800 flex items-center justify-between text-xs text-blue-400 font-semibold">
                <span>View Full Telemetry & History</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition" />
              </div>
            </div>
          );
        })}

        {filteredVehicles.length === 0 && (
          <div className="col-span-full glass-panel rounded-2xl p-10 text-center text-slate-400 space-y-3">
            <Truck className="w-12 h-12 text-slate-600 mx-auto" />
            <div className="text-sm font-bold text-white">No vehicles found matching search</div>
            <p className="text-xs">Try adjusting search filters or registration query.</p>
          </div>
        )}
      </div>
    </div>
  );
};
