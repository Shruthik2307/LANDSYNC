import React, { useState } from 'react';
import { useFleet } from '../../context/FleetContext';
import { formatCurrency } from '../../utils/formatters';
import { CreditCard, Plus, Search, Filter, FileText } from 'lucide-react';

export const ExpensesView = ({ onOpenAddExpense }) => {
  const { expenses, vehicles } = useFleet();
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');

  const filtered = expenses.filter((e) => {
    const veh = vehicles.find((v) => v.id === e.vehicleId);
    const matchesSearch =
      e.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.vendor.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (veh && veh.regNo.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesCat = categoryFilter === 'All' || e.category === categoryFilter;
    return matchesSearch && matchesCat;
  });

  const categories = ['All', 'Fuel', 'Maintenance', 'Toll', 'Permit', 'Parking', 'Repairs', 'Driver Allowance', 'Other'];

  const totalSpend = filtered.reduce((acc, e) => acc + (e.amount || 0), 0);

  return (
    <div className="space-y-5 pb-20">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
            <CreditCard className="w-6 h-6 text-rose-400" />
            <span>Operating Expense Ledger ({expenses.length})</span>
          </h2>
          <p className="text-xs text-slate-400">
            Categorized operational spend tracking, FASTag tolls, permits & vendor vouchers.
          </p>
        </div>

        <button
          onClick={onOpenAddExpense}
          className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-rose-600/30 transition"
        >
          <Plus className="w-4 h-4" />
          <span>Log Expense</span>
        </button>
      </div>

      <div className="glass-card rounded-2xl p-4 border border-slate-700/60 space-y-3">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <input
            type="text"
            placeholder="Search vendor, description or vehicle reg..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full sm:w-80 glass-input rounded-xl px-3 py-2 text-xs"
          />
          <div className="text-xs font-bold text-slate-300">
            Filtered Total: <span className="text-rose-400 font-extrabold text-sm">{formatCurrency(totalSpend)}</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition ${
                categoryFilter === cat
                  ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700/60'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="glass-card rounded-2xl border border-slate-700/60 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-900/80 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
              <tr>
                <th className="p-3">Category</th>
                <th className="p-3">Description</th>
                <th className="p-3">Vehicle</th>
                <th className="p-3">Vendor</th>
                <th className="p-3">Date</th>
                <th className="p-3">Method</th>
                <th className="p-3 text-right">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filtered.map((e) => {
                const veh = vehicles.find((v) => v.id === e.vehicleId);
                return (
                  <tr key={e.id} className="hover:bg-slate-800/40 transition">
                    <td className="p-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300 border border-slate-700">
                        {e.category}
                      </span>
                    </td>
                    <td className="p-3 font-semibold text-white">{e.description}</td>
                    <td className="p-3 text-slate-400">{veh ? veh.regNo : e.vehicleId}</td>
                    <td className="p-3 text-slate-300">{e.vendor}</td>
                    <td className="p-3">{e.date}</td>
                    <td className="p-3 text-slate-400">{e.paymentMethod}</td>
                    <td className="p-3 text-right font-bold text-rose-400">{formatCurrency(e.amount)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
