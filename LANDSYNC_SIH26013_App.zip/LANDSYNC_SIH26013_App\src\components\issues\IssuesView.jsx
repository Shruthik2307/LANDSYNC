import React, { useState } from 'react';
import { useFleet } from '../../context/FleetContext';
import { useAuth } from '../../context/AuthContext';
import { getIssueSeverityColor } from '../../utils/formatters';
import { AlertTriangle, Plus, CheckCircle2, Wrench, ShieldAlert } from 'lucide-react';

export const IssuesView = ({ onOpenReportIssue }) => {
  const { issues, vehicles, drivers, updateIssueStatus } = useFleet();
  const { currentUser } = useAuth();
  const [filterSeverity, setFilterSeverity] = useState('All');

  const filtered = issues.filter((i) => filterSeverity === 'All' || i.severity === filterSeverity);

  return (
    <div className="space-y-5 pb-20">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
            <AlertTriangle className="w-6 h-6 text-rose-400" />
            <span>Driver Vehicle Defect Reports ({issues.length})</span>
          </h2>
          <p className="text-xs text-slate-400">
            Drivers log vehicle issues (Brakes, Engine, Tyre, AC) & Fleet Manager resolves defects.
          </p>
        </div>

        <button
          onClick={onOpenReportIssue}
          className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-rose-600/30 transition"
        >
          <Plus className="w-4 h-4" />
          <span>Report Defect</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((iss) => {
          const veh = vehicles.find((v) => v.id === iss.vehicleId);
          const driver = drivers.find((d) => d.id === iss.driverId);
          const severityClass = getIssueSeverityColor(iss.severity);

          return (
            <div key={iss.id} className="glass-card rounded-2xl p-5 border border-slate-700/60 flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-bold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded">
                      {iss.id}
                    </span>
                    <h3 className="text-sm font-bold text-white mt-1">{iss.category} Issue</h3>
                    <div className="text-xs text-slate-400">
                      Vehicle: <span className="font-bold text-white">{veh ? veh.regNo : iss.vehicleId}</span> | Driver: {driver ? driver.fullName : iss.driverId}
                    </div>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-bold border ${severityClass}`}>
                    {iss.severity} Severity
                  </span>
                </div>

                <div className="mt-3 p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-slate-200">
                  "{iss.description}"
                  <div className="text-[10px] text-slate-400 mt-2">Reported on: {iss.reportedAt}</div>
                </div>
              </div>

              {/* Resolution Workflow Bar */}
              <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
                <span className="text-xs text-slate-400 font-semibold">
                  Status: <span className="text-amber-400 font-bold">{iss.status}</span>
                </span>

                {currentUser.role !== 'Driver' && iss.status !== 'Resolved' && (
                  <div className="flex items-center gap-2">
                    {iss.status === 'Reported' && (
                      <button
                        onClick={() => updateIssueStatus(iss.id, 'In Repair')}
                        className="px-3 py-1 rounded-lg bg-amber-600/30 hover:bg-amber-600/50 text-amber-300 text-xs font-bold border border-amber-500/30"
                      >
                        Send to Repair
                      </button>
                    )}
                    <button
                      onClick={() => updateIssueStatus(iss.id, 'Resolved', 'Fixed by workshop technician')}
                      className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-lg shadow-emerald-600/30"
                    >
                      Mark Resolved
                    </button>
                  </div>
                )}

                {iss.status === 'Resolved' && (
                  <span className="text-xs text-emerald-400 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4" /> Resolved & Cleared
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
