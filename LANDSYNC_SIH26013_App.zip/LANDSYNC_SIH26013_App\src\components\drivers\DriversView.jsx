import React, { useState } from 'react';
import { useFleet } from '../../context/FleetContext';
import { useAuth } from '../../context/AuthContext';
import { formatDate, getDaysRemaining } from '../../utils/formatters';
import {
  Users,
  Plus,
  Search,
  Phone,
  Mail,
  ShieldCheck,
  AlertTriangle,
  Truck,
  Award,
  Calendar,
  ChevronRight
} from 'lucide-react';

export const DriversView = ({ onOpenDriverDetail, onOpenAddDriver }) => {
  const { drivers, vehicles } = useFleet();
  const { currentUser } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');

  const filteredDrivers = drivers.filter((d) => {
    const assignedVeh = vehicles.find((v) => v.id === d.assignedVehicleId);
    return (
      d.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.phone.includes(searchQuery) ||
      d.licenseNo.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (assignedVeh && assignedVeh.regNo.toLowerCase().includes(searchQuery.toLowerCase()))
    );
  });

  return (
    <div className="space-y-5 pb-20">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
            <Users className="w-6 h-6 text-indigo-400" />
            <span>Driver Personnel Directory ({drivers.length})</span>
          </h2>
          <p className="text-xs text-slate-400">
            Driver profiles, license expirations, ratings, and vehicle assignments.
          </p>
        </div>

        {currentUser.role !== 'Driver' && (
          <button
            onClick={onOpenAddDriver}
            className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 transition"
          >
            <Plus className="w-4 h-4" />
            <span>Add Driver</span>
          </button>
        )}
      </div>

      {/* Search */}
      <div className="glass-card rounded-2xl p-4 border border-slate-700/60">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Search by driver name, phone, license number, or assigned vehicle..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full glass-input rounded-xl pl-10 pr-4 py-2.5 text-xs placeholder:text-slate-500"
          />
        </div>
      </div>

      {/* Drivers List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredDrivers.map((driver) => {
          const assignedVeh = vehicles.find((v) => v.id === driver.assignedVehicleId);
          const daysToExpiry = getDaysRemaining(driver.licenseExpiry);

          let expiryBadge = null;
          if (daysToExpiry < 0) {
            expiryBadge = (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-400 border border-rose-500/30">
                License Expired
              </span>
            );
          } else if (daysToExpiry <= 30) {
            expiryBadge = (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">
                Expires in {daysToExpiry}d
              </span>
            );
          } else {
            expiryBadge = (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                Valid License
              </span>
            );
          }

          return (
            <div
              key={driver.id}
              onClick={() => onOpenDriverDetail(driver)}
              className="glass-card rounded-2xl p-4 border border-slate-700/60 hover:border-indigo-500/50 transition cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={driver.photo}
                      alt={driver.fullName}
                      className="w-12 h-12 rounded-xl object-cover border border-slate-700"
                    />
                    <div>
                      <div className="font-bold text-white text-sm">{driver.fullName}</div>
                      <div className="text-[11px] text-slate-400 flex items-center gap-1">
                        <Award className="w-3 h-3 text-amber-400" />
                        <span>Rating: {driver.rating} ★ ({driver.totalTrips} Trips)</span>
                      </div>
                    </div>
                  </div>
                  {expiryBadge}
                </div>

                <div className="mt-4 space-y-2 text-xs border-t border-slate-800 pt-3">
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="text-slate-400 flex items-center gap-1">
                      <Phone className="w-3.5 h-3.5 text-blue-400" />
                      Phone:
                    </span>
                    <span className="font-semibold">{driver.phone}</span>
                  </div>

                  <div className="flex items-center justify-between text-slate-300">
                    <span className="text-slate-400 flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
                      License No:
                    </span>
                    <span className="font-semibold text-slate-200">{driver.licenseNo}</span>
                  </div>

                  <div className="flex items-center justify-between text-slate-300">
                    <span className="text-slate-400 flex items-center gap-1">
                      <Truck className="w-3.5 h-3.5 text-emerald-400" />
                      Assigned Vehicle:
                    </span>
                    <span className="font-bold text-emerald-400">
                      {assignedVeh ? assignedVeh.regNo : 'Unassigned'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-indigo-400 font-semibold">
                <span>View Driver Profile</span>
                <ChevronRight className="w-4 h-4" />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
