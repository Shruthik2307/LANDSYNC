import React from 'react';
import { X, CheckCircle2, HelpCircle, ArrowRight } from 'lucide-react';

export const WalkthroughModal = ({ isOpen, onClose, onSelectStep }) => {
  if (!isOpen) return null;

  const criteria = [
    { step: 1, title: 'Company Account & Session', desc: 'Pre-configured with Veloce Logistics India (CIN & GSTIN)', tab: 'settings' },
    { step: 2, title: 'Login & Multi-Role Switching', desc: 'Use top right dropdown to switch between Admin, Manager, and Driver', tab: 'dashboard' },
    { step: 3, title: 'Add a Vehicle', desc: 'Register commercial truck/pickup with specs & registration', tab: 'vehicles' },
    { step: 4, title: 'Add a Driver', desc: 'Add driver profile with license number & photo', tab: 'drivers' },
    { step: 5, title: 'Assign Driver to Vehicle', desc: 'Link driver to vehicle in vehicle detail sheet or driver list', tab: 'vehicles' },
    { step: 6, title: 'Create & Dispatch Trip', desc: 'Set customer name, start location, destination & expected revenue', tab: 'trips' },
    { step: 7, title: 'Start the Trip', desc: 'Advance trip workflow status from Scheduled to Started', tab: 'trips' },
    { step: 8, title: 'Complete the Trip', desc: 'Enter ending odometer reading to calculate distance & trip profit', tab: 'trips' },
    { step: 9, title: 'Record Fuel Usage', desc: 'Log fuel receipt with station, litres, price/L & odometer', tab: 'fuel' },
    { step: 10, title: 'Add Operating Expenses', desc: 'Log FASTag toll, permit fees or driver allowance', tab: 'expenses' },
    { step: 11, title: 'Record Maintenance', desc: 'Schedule service or log parts vs labor repair invoice', tab: 'maintenance' },
    { step: 12, title: 'Upload Vehicle Documents', desc: 'Store RC, Insurance or PUC with automated expiry alarms', tab: 'documents' },
    { step: 13, title: 'Expiry & Maintenance Alerts', desc: 'View countdown badges (Valid, Expiring Soon, Expired)', tab: 'documents' },
    { step: 14, title: 'View Vehicle Telemetry & History', desc: 'Open multi-tab vehicle modal for full trips, fuel & cost/KM', tab: 'vehicles' },
    { step: 15, title: 'View Fleet Dashboard & Analytics', desc: 'KPI cards, net profit, financial breakdown & SVG charts', tab: 'dashboard' },
    { step: 16, title: 'Generate & Export Reports', desc: 'Preview Fleet/Trip reports & download CSV or print PDF', tab: 'reports' },
    { step: 17, title: 'Search, Filter & Sort Records', desc: 'Filter vehicles, trips, drivers & expenses instantly', tab: 'vehicles' },
    { step: 18, title: 'Driver Role View', desc: 'Switch role to Driver to see mobile-focused driver assignment', tab: 'dashboard' },
    { step: 19, title: 'Driver Defect Reporting', desc: 'Log vehicle mechanical/electrical defect with severity', tab: 'issues' },
    { step: 20, title: 'Manager Defect Resolution', desc: 'Switch role to Manager to send to repair or mark resolved', tab: 'issues' },
    { step: 21, title: 'Notification Center', desc: 'View unread alert counters and mark all read', tab: 'dashboard' },
    { step: 22, title: 'Immutable Audit Log', desc: 'Verify all database mutations are logged with timestamp & user', tab: 'audit' }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-5">
      <div className="w-full max-w-2xl glass-panel rounded-2xl border border-slate-700/80 p-5 shadow-2xl animate-fade-in max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between pb-4 border-b border-slate-700/60">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400">
              <HelpCircle className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-white">
                22-Step Acceptance Criteria Checklist
              </h2>
              <p className="text-xs text-slate-400">
                Interactive guide to test every production capability of FleetPulse
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto pt-4 space-y-2.5 pr-1 text-xs">
          {criteria.map((item) => (
            <div
              key={item.step}
              onClick={() => {
                onSelectStep(item.tab);
                onClose();
              }}
              className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 hover:border-indigo-500/50 transition cursor-pointer flex items-start justify-between gap-3 group"
            >
              <div className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 font-extrabold text-[11px] flex items-center justify-center shrink-0">
                  {item.step}
                </span>
                <div>
                  <div className="font-bold text-white group-hover:text-indigo-300 transition">
                    {item.title}
                  </div>
                  <div className="text-slate-400 text-[11px] mt-0.5">{item.desc}</div>
                </div>
              </div>
              <span className="text-indigo-400 font-bold text-[11px] flex items-center gap-1 shrink-0">
                <span>Go to module</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition" />
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
